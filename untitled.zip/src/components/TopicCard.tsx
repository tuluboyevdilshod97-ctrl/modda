import React from 'react';
import { Scale, Landmark, Briefcase, UserCheck, ShieldAlert, HeartHandshake, ArrowRight, Play, BookOpen } from 'lucide-react';
import { Topic } from '../types';

interface TopicCardProps {
  topic: Topic;
  questionCount: number;
  onSelectTopic: (topic: Topic, mode: 'practice' | 'quiz') => void;
}

const ICONS_MAP: Record<string, React.FC<{ className?: string }>> = {
  Scale,
  Landmark,
  Briefcase,
  UserCheck,
  ShieldAlert,
  HeartHandshake
};

export const TopicCard: React.FC<TopicCardProps> = ({
  topic,
  questionCount,
  onSelectTopic
}) => {
  const Icon = ICONS_MAP[topic.iconName] || Scale;

  return (
    <div
      id={`topic-card-${topic.id}`}
      className="group relative bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-6 transition-all duration-200 hover:shadow-xl hover:shadow-emerald-950/20 flex flex-col justify-between"
    >
      <div>
        {/* Top Badges */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 group-hover:bg-emerald-500/20 transition-all">
            <Icon className="w-6 h-6" />
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full">
              {topic.badge}
            </span>
            <span className="text-[11px] font-medium text-slate-400 bg-slate-800 px-2 py-1 rounded-full">
              {questionCount} ta savol
            </span>
          </div>
        </div>

        {/* Title and subtitle */}
        <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition-colors mb-1">
          {topic.title}
        </h3>
        <p className="text-xs font-medium text-emerald-400/90 mb-3">
          {topic.subtitle}
        </p>

        {/* Description */}
        <p className="text-xs text-slate-400 leading-relaxed line-clamp-3 mb-6">
          {topic.description}
        </p>
      </div>

      {/* Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-4 border-t border-slate-800/80">
        <button
          id={`btn-practice-${topic.id}`}
          onClick={() => onSelectTopic(topic, 'practice')}
          className="flex items-center justify-center space-x-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-colors"
          title="Har bir savol izohi bilan o'rganish"
        >
          <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
          <span>O‘rganish</span>
        </button>

        <button
          id={`btn-quiz-${topic.id}`}
          onClick={() => onSelectTopic(topic, 'quiz')}
          className="flex items-center justify-center space-x-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-sm shadow-emerald-600/30 transition-all active:scale-95"
          title="Vaqtli sinov testi"
        >
          <Play className="w-3.5 h-3.5" />
          <span>Sinov</span>
        </button>
      </div>
    </div>
  );
};
