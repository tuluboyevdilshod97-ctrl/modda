import React from 'react';
import { Clock, Menu } from 'lucide-react';

interface HeaderProps {
  onStartDtmExam: () => void;
  onStartAralashTest?: () => void;
  onOpenCheatSheet?: () => void;
  onOpenStats?: () => void;
  onStartMistakesPractice?: () => void;
  mistakesCount?: number;
  onGoHome: () => void;
  activeView: 'home' | 'quiz' | 'result';
  onOpenNavMenu: (tab?: 'sozlamalar' | 'manbalar' | 'xronologiya') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onStartDtmExam,
  onGoHome,
  activeView,
  onOpenNavMenu
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand */}
          <button
            onClick={onGoHome}
            id="brand-logo-btn"
            className="flex items-center space-x-3 text-left focus:outline-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#F59E0B] flex items-center justify-center shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <span className="text-white font-black text-2xl leading-none transform -rotate-12 select-none pb-0.5">
                m
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl sm:text-2xl tracking-tight text-white group-hover:text-amber-400 transition-colors uppercase font-sans">
                  MODDA
                </span>
                <span className="text-[10px] uppercase font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded">
                  Huquq platformasi
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Huquqiy testlar va davlat qonunchiligi tahlili
              </p>
            </div>
          </button>

          {/* Quick Nav Controls */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* DTM Exam CTA */}
            {activeView !== 'quiz' && (
              <button
                id="header-dtm-cta-btn"
                onClick={onStartDtmExam}
                className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 active:scale-95 transition-all"
              >
                <Clock className="w-4 h-4" />
                <span>DTM Sinov</span>
              </button>
            )}

            {/* Toggle Navigation Menu Button */}
            <button
              id="header-nav-toggle-btn"
              onClick={() => onOpenNavMenu('sozlamalar')}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 active:scale-95 transition-all"
              title="Navigatsiya menyusi: Sozlamalar, Manbalar, Yillar xronologiyasi"
            >
              <Menu className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">Menyu</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

