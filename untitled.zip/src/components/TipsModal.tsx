import React, { useState } from 'react';
import {
  X,
  Award,
  CheckCircle,
  Clock,
  Sparkles,
  BookOpen,
  ArrowRight,
  Search,
  BookMarked,
  User,
  Calendar,
  Building,
  Landmark
} from 'lucide-react';
import { CHEAT_SHEET_ITEMS } from '../data/cheatSheet';
import { LegalCheatItem } from '../types';

interface TipsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartExam?: () => void;
  initialTab?: 'cheatsheet' | 'tips';
}

export const TipsModal: React.FC<TipsModalProps> = ({
  isOpen,
  onClose,
  onStartExam,
  initialTab = 'cheatsheet'
}) => {
  const [activeTab, setActiveTab] = useState<'cheatsheet' | 'tips'>(initialTab);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'Barchasi', icon: BookMarked },
    { id: 'yosh', label: 'Yosh mezonlari', icon: User },
    { id: 'muddat', label: 'Muhim muddatlar', icon: Calendar },
    { id: 'davlat', label: 'Davlat organlari', icon: Building },
    { id: 'saylov', label: 'Saylov va muddatlar', icon: Landmark }
  ];

  const filteredCheatItems = CHEAT_SHEET_ITEMS.filter((item: LegalCheatItem) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const query = searchQuery.toLowerCase();
    const matchesQuery =
      item.title.toLowerCase().includes(query) ||
      item.value.toLowerCase().includes(query) ||
      item.details.toLowerCase().includes(query) ||
      item.article.toLowerCase().includes(query);
    return matchesCategory && matchesQuery;
  });

  const tips = [
    {
      id: 'tip-1',
      num: '01',
      title: 'Konstitutsiyaning yangi tahriri va muhim moddalar',
      badge: 'Eng ko‘p tushadigan',
      badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      description:
        '2023-yilgi referendumda qabul qilingan yangi tahrirdagi O‘zbekiston Respublikasi Konstitutsiyasining o‘zgargan moddalariga alohida e’tibor bering.',
      points: [
        'Miranda qoidasi (ushlangan shaxsga uning huquqlari tushuntirilishi shart)',
        'Habeas Corpus (sud qarorisiz 48 soatdan ortiq ushlab turilishi mumkin emas)',
        'Senat a’zolari soni (100 nafardan 65 nafarga tushirilgan)',
        'Prezidentlik muddati (5 yildan 7 yilga uzaytirilgan)'
      ]
    },
    {
      id: 'tip-2',
      num: '02',
      title: 'Yoshlar, muddatlar va miqdorlar mezonlari',
      badge: 'Yod olish shart',
      badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      description:
        'Huquq testlarining eng nozik savollari yosh chegaralari va protsessual muddatlarga bog‘liq bo‘ladi.',
      points: [
        'Fuqarolik umumiy muomala layoqati — 18 yosh, cheklangan layoqat — 14 yoshdan',
        'Mehnatga qabul qilishning umumiy yoshi — 16 yosh (ota-ona roziligi bilan 15 yosh)',
        'Umumiy da’vo muddati — 3 yil (maxsus muddatlar qonunda belgilangan)',
        'Yangi Mehnat kodeksida asosiy yillik uzaytirilgan mehnat ta’tili — kamida 21 kalendar kuni'
      ]
    },
    {
      id: 'tip-3',
      num: '03',
      title: 'Xatolar ustida ishlash va tahlil qilish strategiyasi',
      badge: 'Natija siri',
      badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
      description:
        'Shunchaki test yechish yetarli emas. Noto‘g‘ri belgilangan har bir savolning huquqiy asosini (moddasini) tahlil qiling.',
      points: [
        'Har bir test yakunida berilgan tushuntirish va havola qilingan moddani to‘liq o‘qing',
        'Ilovadagi "Xatolar ustida ishlash" bo‘limidan foydalanib, xato savollarni qayta ishlang',
        'Shubhali savollarni bayroqcha (flag) bilan belgilab, keyinroq qayta tekshiring'
      ]
    },
    {
      id: 'tip-4',
      num: '04',
      title: 'DTM da vaqtni to‘g‘ri boshqarish taktikasi',
      badge: 'Vaqtni tejash',
      badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
      description:
        '30 ta savol uchun 40 daqiqa vaqt ajratiladi. Har bir savolga o‘rtacha 1 daqiqa 20 soniya to‘g‘ri keladi.',
      points: [
        'Birinchi bosqichda faqat 100% ishonchingiz komil bo‘lgan oson savollarni tezda belgilang',
        'Ikkilanish tug‘dirgan savollarga 2 daqiqadan ortiq vaqt sarflamang, ularni keyinga qoldiring',
        'Oxirgi 5 daqiqani javoblar varaqasini yoki tizimni to‘liq tekshirib chiqishga ajrating'
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div
        id="tips-modal"
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/95 sticky top-0 z-10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Huquqiy Shpargalka & DTM Tavsiyalari
              </h2>
              <p className="text-xs text-slate-400">
                DTM testlarida eng ko‘p uchraydigan yoshlar, muddatlar va metodik ko‘rsatmalar
              </p>
            </div>
          </div>
          <button
            id="close-tips-modal-btn"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center space-x-2 px-6 pt-3 pb-2 border-b border-slate-800/80 bg-slate-950/40">
          <button
            id="tab-btn-cheatsheet"
            onClick={() => setActiveTab('cheatsheet')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'cheatsheet'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookMarked className="w-4 h-4" />
            <span>Huquqiy Shpargalka (Yoshlar & Muddatlar)</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-black/20 font-mono font-bold">
              {CHEAT_SHEET_ITEMS.length}
            </span>
          </button>

          <button
            id="tab-btn-tips"
            onClick={() => setActiveTab('tips')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'tips'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>DTM Imtihon Tavsiyalari</span>
          </button>
        </div>

        {/* Tab 1: Shpargalka */}
        {activeTab === 'cheatsheet' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Search & Categories */}
            <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/30 space-y-3 shrink-0">
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  id="cheatsheet-search-input"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Qidirish: masalan 14 yosh, da'vo muddati, 7 yil, aliment, sudyalik..."
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              {/* Category Tabs */}
              <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
                {categories.map((cat) => {
                  const Icon = cat.icon;
                  const isActive = activeCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      id={`cat-btn-${cat.id}`}
                      onClick={() => setActiveCategory(cat.id)}
                      className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                        isActive
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Shpargalka Cards */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
              {filteredCheatItems.length === 0 ? (
                <div className="text-center py-12 text-slate-400">
                  <p className="text-base font-semibold text-slate-300">Hech qanday ma'lumot topilmadi</p>
                  <p className="text-xs mt-1">Boshqa so‘z yoki kategoriya orqali qidirib ko‘ring</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredCheatItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 hover:border-amber-500/50 hover:bg-slate-800 transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <span className="text-base font-bold text-amber-400 font-mono">
                            {item.title}
                          </span>
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-700 text-slate-300 border border-slate-600 shrink-0">
                            {item.category === 'yosh' && 'Yosh mezoni'}
                            {item.category === 'muddat' && 'Muddat'}
                            {item.category === 'davlat' && 'Davlat'}
                            {item.category === 'saylov' && 'Saylov'}
                          </span>
                        </div>
                        <h4 className="text-xs sm:text-sm font-semibold text-white mb-2">
                          {item.value}
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {item.details}
                        </p>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-amber-400/90 font-medium">
                        <span>Asos: {item.article}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Tips */}
        {activeTab === 'tips' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs sm:text-sm flex items-start space-x-3">
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-200 block font-semibold mb-0.5">
                  DTM Huquq fanidan asosiy talab:
                </strong>
                <span>
                  Savollarda faqat qonun matnidagi aniq normalar, moddalar va muddatlar so‘raladi. O‘z taxminingizga emas, rasmiy qonunchilikka tayanishingiz muvaffaqiyat garovidir.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {tips.map((tip) => (
                <div
                  key={tip.id}
                  className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700 hover:border-amber-500/40 transition-all space-y-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center space-x-2.5">
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-700 text-amber-400 border border-slate-600">
                        {tip.num}
                      </span>
                      <h3 className="text-base font-bold text-white">{tip.title}</h3>
                    </div>
                    <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${tip.badgeColor} shrink-0`}>
                      {tip.badge}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {tip.description}
                  </p>

                  <div className="pt-2 border-t border-slate-700/80 space-y-1.5">
                    {tip.points.map((pt, idx) => (
                      <div key={idx} className="flex items-start space-x-2 text-xs sm:text-sm text-slate-400">
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <BookOpen className="w-4 h-4 text-amber-400" />
            Amaldagi O‘zbekiston Respublikasi qonunchiligi asosida tuzilgan
          </span>
          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold transition-colors"
            >
              Yopish
            </button>
            {onStartExam && (
              <button
                onClick={() => {
                  onClose();
                  onStartExam();
                }}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold shadow-lg shadow-amber-500/20 transition-all"
              >
                <span>DTM Testni boshlash</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

