import React, { useState } from 'react';
import { X, Search, BookMarked, Calendar, User, Building, Landmark, CheckCircle } from 'lucide-react';
import { CHEAT_SHEET_ITEMS } from '../data/cheatSheet';
import { LegalCheatItem } from '../types';

interface CheatSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheatSheetModal: React.FC<CheatSheetModalProps> = ({ isOpen, onClose }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const filteredItems = CHEAT_SHEET_ITEMS.filter((item: LegalCheatItem) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const query = searchQuery.toLowerCase();
    const matchesQuery =
      item.title.toLowerCase().includes(query) ||
      item.value.toLowerCase().includes(query) ||
      item.details.toLowerCase().includes(query) ||
      item.article.toLowerCase().includes(query);
    return matchesCategory && matchesQuery;
  });

  const categories = [
    { id: 'all', label: 'Barchasi', icon: BookMarked },
    { id: 'yosh', label: 'Yosh mezonlari', icon: User },
    { id: 'muddat', label: 'Muhim muddatlar', icon: Calendar },
    { id: 'davlat', label: 'Davlat organlari', icon: Building },
    { id: 'saylov', label: 'Saylov va muddatlar', icon: Landmark }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div
        id="cheatsheet-modal"
        className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <BookMarked className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Huquqiy Shpargalka & Muhim Mezonlar</h2>
              <p className="text-xs text-slate-400">
                DTM testlarida eng ko‘p uchraydigan yoshlar, muddatlar va huquqiy normalar
              </p>
            </div>
          </div>
          <button
            id="close-cheatsheet-btn"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Categories */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/40 space-y-3">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              id="cheatsheet-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Qidirish: masalan 14 yosh, da'vo muddati, 7 yil, aliment..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`cat-btn-${cat.id}`}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-sm">So‘rovingiz bo‘yicha ma’lumot topilmadi.</p>
            </div>
          ) : (
            filteredItems.map((item) => (
              <div
                key={item.id}
                id={`cheat-item-${item.id}`}
                className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 hover:border-slate-600 transition-all hover:shadow-md"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-1 text-xs font-bold rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      {item.title}
                    </span>
                    <span className="font-semibold text-sm text-white">{item.value}</span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400/90 bg-slate-900 px-2 py-0.5 rounded border border-slate-700 shrink-0">
                    {item.article}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {item.details}
                </p>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between text-xs text-slate-400">
          <span>Jami mezonlar: {filteredItems.length} ta</span>
          <button
            id="cheatsheet-gotit-btn"
            onClick={onClose}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-medium transition-colors"
          >
            Tushundim, yopish
          </button>
        </div>
      </div>
    </div>
  );
};
