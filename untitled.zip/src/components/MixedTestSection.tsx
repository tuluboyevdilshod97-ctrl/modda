import React, { useState } from 'react';
import {
  Shuffle,
  Sparkles,
  Layers,
  CheckCircle2,
  Clock,
  BookOpen,
  Filter,
  Search,
  ChevronDown,
  ChevronUp,
  Award,
  Flame,
  HelpCircle
} from 'lucide-react';
import { Question } from '../types';
import { USER_MIXED_QUESTIONS, USER_QUESTIONS_STATS, shuffleQuestions } from '../data/userQuestions';

interface MixedTestSectionProps {
  onStartCustomQuiz: (questions: Question[], title: string, timeLimitSeconds: number) => void;
}

export const MixedTestSection: React.FC<MixedTestSectionProps> = ({ onStartCustomQuiz }) => {
  const [selectedTopicFilter, setSelectedTopicFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);

  // Filtered preview questions
  const filteredQuestions = USER_MIXED_QUESTIONS.filter((q) => {
    const matchesTopic = selectedTopicFilter === 'all' || q.topicId === selectedTopicFilter;
    const matchesSearch =
      searchQuery.trim() === '' ||
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.options.some((opt) => opt.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesTopic && matchesSearch;
  });

  // Start 30 random questions test (standard DTM)
  const handleStart30Random = () => {
    const shuffled = shuffleQuestions(USER_MIXED_QUESTIONS);
    const selected = shuffled.slice(0, 30);
    onStartCustomQuiz(selected, "Aralash Test: 30 ta Tasodifiy Savol (DTM)", 40 * 60);
  };

  // Start 50 random questions test
  const handleStart50Random = () => {
    const shuffled = shuffleQuestions(USER_MIXED_QUESTIONS);
    const selected = shuffled.slice(0, 50);
    onStartCustomQuiz(selected, "Aralash Test: 50 ta Tasodifiy Savol (Intensiv)", 65 * 60);
  };

  // Start full 131 questions marathon
  const handleStartFullMarathon = () => {
    const shuffled = shuffleQuestions(USER_MIXED_QUESTIONS);
    onStartCustomQuiz(shuffled, "Aralash Test: To‘liq Marafon (131 ta Savol)", 150 * 60);
  };

  // Start filtered topic in random order
  const handleStartTopicRandom = (topicId: string, topicLabel: string) => {
    const topicList = USER_MIXED_QUESTIONS.filter((q) => q.topicId === topicId);
    const shuffled = shuffleQuestions(topicList);
    onStartCustomQuiz(
      shuffled,
      `Aralash Test: ${topicLabel} (${shuffled.length} ta random savol)`,
      shuffled.length * 90
    );
  };

  return (
    <section id="aralash-testlar-section" className="mb-12 scroll-mt-20">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900 via-slate-900 to-teal-950 border border-indigo-500/30 shadow-2xl p-6 sm:p-8 text-white">
        {/* Decorative background glow */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-16 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-indigo-500/20 rounded-xl border border-indigo-500/40 text-indigo-300">
                <Shuffle className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
                    Aralash Testlar Bo‘limi
                  </h2>
                  <span className="bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 text-xs font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    Maxsus Bank
                  </span>
                </div>
                <p className="text-sm text-slate-300 mt-0.5">
                  Siz taqdim etgan 131 ta saralangan va moddalar bilan tasdiqlangan savollar to‘plami
                </p>
              </div>
            </div>

            {/* Total Badge */}
            <div className="flex items-center space-x-2 bg-slate-800/80 backdrop-blur border border-slate-700/80 px-4 py-2 rounded-xl">
              <Layers className="w-4 h-4 text-emerald-400" />
              <span className="text-sm font-semibold text-slate-200">Jami savollar:</span>
              <span className="text-base font-bold text-emerald-400">{USER_MIXED_QUESTIONS.length} ta</span>
            </div>
          </div>

          {/* Quick Stats of Resorted Categories */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 my-6">
            <button
              onClick={() => handleStartTopicRandom('konstitutsiya', 'Konstitutsiya')}
              className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-emerald-500/50 p-3 rounded-xl text-left transition-all group"
            >
              <span className="text-xs text-slate-400 group-hover:text-emerald-300">Konstitutsiya</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-lg font-bold text-emerald-400">{USER_QUESTIONS_STATS.byTopic.konstitutsiya} ta</span>
                <span className="text-[10px] text-slate-400">Random ⚡</span>
              </div>
            </button>

            <button
              onClick={() => handleStartTopicRandom('davlat_huquq', 'Davlat va huquq nazariyasi')}
              className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-sky-500/50 p-3 rounded-xl text-left transition-all group"
            >
              <span className="text-xs text-slate-400 group-hover:text-sky-300">Davlat nazariyasi</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-lg font-bold text-sky-400">{USER_QUESTIONS_STATS.byTopic.davlat_huquq} ta</span>
                <span className="text-[10px] text-slate-400">Random ⚡</span>
              </div>
            </button>

            <button
              onClick={() => handleStartTopicRandom('mehnat', 'Mehnat huquqi')}
              className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-amber-500/50 p-3 rounded-xl text-left transition-all group"
            >
              <span className="text-xs text-slate-400 group-hover:text-amber-300">Mehnat huquqi</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-lg font-bold text-amber-400">{USER_QUESTIONS_STATS.byTopic.mehnat} ta</span>
                <span className="text-[10px] text-slate-400">Random ⚡</span>
              </div>
            </button>

            <button
              onClick={() => handleStartTopicRandom('jinoyat', 'Jinoyat huquqi')}
              className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-rose-500/50 p-3 rounded-xl text-left transition-all group"
            >
              <span className="text-xs text-slate-400 group-hover:text-rose-300">Jinoyat huquqi</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-lg font-bold text-rose-400">{USER_QUESTIONS_STATS.byTopic.jinoyat} ta</span>
                <span className="text-[10px] text-slate-400">Random ⚡</span>
              </div>
            </button>

            <button
              onClick={() => handleStartTopicRandom('fuqarolik', 'Fuqarolik huquqi')}
              className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-indigo-500/50 p-3 rounded-xl text-left transition-all group"
            >
              <span className="text-xs text-slate-400 group-hover:text-indigo-300">Fuqarolik huquqi</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-lg font-bold text-indigo-400">{USER_QUESTIONS_STATS.byTopic.fuqarolik} ta</span>
                <span className="text-[10px] text-slate-400">Random ⚡</span>
              </div>
            </button>

            <button
              onClick={() => handleStartTopicRandom('mamuriy_oila', 'Ma’muriy va oila')}
              className="bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-purple-500/50 p-3 rounded-xl text-left transition-all group"
            >
              <span className="text-xs text-slate-400 group-hover:text-purple-300">Ma’muriy & Oila</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-lg font-bold text-purple-400">{USER_QUESTIONS_STATS.byTopic.mamuriy_oila} ta</span>
                <span className="text-[10px] text-slate-400">Random ⚡</span>
              </div>
            </button>
          </div>

          {/* Primary Action Buttons (Random Quiz Launchers) */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
            <button
              id="start-30-random-btn"
              onClick={handleStart30Random}
              className="flex-1 flex items-center justify-center space-x-2.5 px-5 py-3.5 rounded-xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-700/30 active:scale-[0.98] transition-all"
            >
              <Shuffle className="w-5 h-5 text-emerald-200" />
              <span>30 ta Random Sinov (DTM standarti)</span>
              <span className="bg-emerald-800/60 text-xs px-2 py-0.5 rounded-md text-emerald-200 font-semibold">
                40 daqiqa
              </span>
            </button>

            <button
              id="start-50-random-btn"
              onClick={handleStart50Random}
              className="flex-1 flex items-center justify-center space-x-2 px-5 py-3.5 rounded-xl font-semibold bg-indigo-600/80 hover:bg-indigo-600 text-white border border-indigo-400/30 shadow-md active:scale-[0.98] transition-all"
            >
              <Flame className="w-5 h-5 text-indigo-200" />
              <span>50 ta Katta Random Sinov</span>
              <span className="bg-indigo-900/60 text-xs px-2 py-0.5 rounded-md text-indigo-200 font-medium">
                65 daqiqa
              </span>
            </button>

            <button
              id="start-all-marathon-btn"
              onClick={handleStartFullMarathon}
              className="flex items-center justify-center space-x-2 px-5 py-3.5 rounded-xl font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 active:scale-[0.98] transition-all"
            >
              <Award className="w-5 h-5 text-amber-400" />
              <span>Barcha 131 ta Marafon</span>
            </button>
          </div>

          {/* Toggle Question Bank Preview */}
          <div className="mt-6 pt-4 border-t border-slate-700/60 flex items-center justify-between">
            <button
              onClick={() => setIsPreviewOpen(!isPreviewOpen)}
              className="flex items-center space-x-2 text-xs sm:text-sm font-semibold text-indigo-300 hover:text-white transition-colors"
            >
              <BookOpen className="w-4 h-4" />
              <span>
                {isPreviewOpen
                  ? "Savollar bankini yashirish"
                  : "Ushbu 131 ta savol va javoblar bankini ko‘rish / qidirish"}
              </span>
              {isPreviewOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            <span className="text-xs text-slate-400">
              Har bir sinovda variantlar va savollar random aralashtiriladi
            </span>
          </div>
        </div>
      </div>

      {/* Collapsible Question Bank Preview & Search */}
      {isPreviewOpen && (
        <div className="mt-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
          {/* Filter and Search Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-5">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Savol yoki kalit so‘zni qidiring..."
                className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Topic tabs */}
            <div className="flex items-center space-x-1.5 overflow-x-auto w-full sm:w-auto pb-1">
              {[
                { id: 'all', label: 'Barchasi (131)' },
                { id: 'konstitutsiya', label: 'Konstitutsiya' },
                { id: 'davlat_huquq', label: 'Davlat nazariyasi' },
                { id: 'mehnat', label: 'Mehnat' },
                { id: 'jinoyat', label: 'Jinoyat' },
                { id: 'fuqarolik', label: 'Fuqarolik' },
                { id: 'mamuriy_oila', label: 'Ma’muriy/Oila' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTopicFilter(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    selectedTopicFilter === tab.id
                      ? 'bg-indigo-600 text-white font-semibold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Questions list */}
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
            {filteredQuestions.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-sm">
                Qidiruvingiz bo‘yicha savol topilmadi.
              </div>
            ) : (
              filteredQuestions.map((q, idx) => {
                const isExpanded = expandedQuestionId === q.id;
                return (
                  <div
                    key={q.id}
                    className="p-3.5 bg-slate-800/80 border border-slate-700/80 rounded-xl hover:border-slate-600 transition-colors text-slate-200"
                  >
                    <div
                      onClick={() => setExpandedQuestionId(isExpanded ? null : q.id)}
                      className="flex items-start justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-start space-x-3">
                        <span className="w-6 h-6 rounded-full bg-slate-700 text-slate-300 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <div>
                          <p className="text-sm font-medium text-slate-100">{q.question}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <span className="text-[11px] font-semibold text-indigo-400 bg-indigo-950/60 border border-indigo-800 px-2 py-0.5 rounded">
                              {q.topicId}
                            </span>
                            {q.legalBasis && (
                              <span className="text-[11px] text-slate-400">
                                ⚖️ {q.legalBasis}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <button className="text-slate-400 hover:text-slate-200 p-1 shrink-0">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>

                    {isExpanded && (
                      <div className="mt-3 pt-3 border-t border-slate-700/60 pl-9">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
                          {q.options.map((opt, oIdx) => {
                            const isCorrect = oIdx === q.correctIndex;
                            return (
                              <div
                                key={oIdx}
                                className={`p-2.5 rounded-lg text-xs font-medium flex items-center space-x-2 border ${
                                  isCorrect
                                    ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-200'
                                    : 'bg-slate-900/60 border-slate-800 text-slate-300'
                                }`}
                              >
                                <span
                                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                    isCorrect ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'
                                  }`}
                                >
                                  {['A', 'B', 'C', 'D'][oIdx]}
                                </span>
                                <span className="flex-1">{opt}</span>
                                {isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                              </div>
                            );
                          })}
                        </div>

                        {q.explanation && (
                          <div className="bg-slate-900/90 border border-slate-700/50 p-2.5 rounded-lg text-xs text-slate-300">
                            <span className="font-semibold text-emerald-400">Huquqiy izoh: </span>
                            {q.explanation}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </section>
  );
};
