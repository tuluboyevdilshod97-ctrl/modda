import React, { useState } from 'react';
import {
  Trophy,
  CheckCircle2,
  XCircle,
  Clock,
  RotateCcw,
  ArrowLeft,
  Filter,
  Lightbulb,
  AlertCircle,
  Share2,
  BookOpen
} from 'lucide-react';
import { Question, QuizSession } from '../types';

interface ResultViewProps {
  session: QuizSession;
  onRestart: () => void;
  onGoHome: () => void;
  onStartMistakesPractice: () => void;
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'];

export const ResultView: React.FC<ResultViewProps> = ({
  session,
  onRestart,
  onGoHome,
  onStartMistakesPractice
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'wrong' | 'correct'>('all');

  const total = session.questions.length;
  let correctCount = 0;
  let wrongCount = 0;
  let unansweredCount = 0;

  session.questions.forEach((q) => {
    const userChoice = session.userAnswers[q.id];
    if (userChoice === undefined) {
      unansweredCount++;
    } else if (userChoice === q.correctIndex) {
      correctCount++;
    } else {
      wrongCount++;
    }
  });

  const percentage = total > 0 ? Math.round((correctCount / total) * 100) : 0;
  // DTM standard: each question carries 3.1 points (out of ~93 for 30 questions)
  const dtmScore = (correctCount * 3.1).toFixed(1);
  const maxDtmScore = (total * 3.1).toFixed(1);

  // Status message
  let statusBadge = {
    title: "Ko‘proq tayyorlanish kerak",
    color: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
    desc: 'Savollar ustida yana bir bor ishlab, qonun moddalarini qayta takrorlang.'
  };

  if (percentage >= 85) {
    statusBadge = {
      title: "A’lo daraja — Davlat Granti ehtimoli yuqori!",
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
      desc: 'Huquqshunoslik fanidan bilimingiz mustahkam. Shu sur’atda davom eting!'
    };
  } else if (percentage >= 65) {
    statusBadge = {
      title: "Yaxshi natija — To‘lov-shartnoma ehtimoli",
      color: 'text-sky-400 bg-sky-500/10 border-sky-500/30',
      desc: 'Yaxshi natija, ammo grant uchun bir nechta xatolar ustida ishlash tavsiya etiladi.'
    };
  } else if (percentage >= 45) {
    statusBadge = {
      title: "Qoniqarli — Takrorlash tavsiya etiladi",
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
      desc: 'Ayniqsa yoshlar va muddatlar bilan bog‘liq mezonlarni diqqat bilan o‘rganing.'
    };
  }

  // Filtered questions
  const filteredQuestions = session.questions.filter((q) => {
    const userChoice = session.userAnswers[q.id];
    const isCorrect = userChoice === q.correctIndex;
    if (filterMode === 'correct') return isCorrect;
    if (filterMode === 'wrong') return !isCorrect;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      {/* Top Banner Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-center">
        {/* Decorative background glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
            <Trophy className="w-8 h-8" />
          </div>

          <span
            className={`inline-block px-3 py-1 rounded-full text-xs font-bold border mb-3 ${statusBadge.color}`}
          >
            {statusBadge.title}
          </span>

          <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">
            {dtmScore} <span className="text-xl text-slate-400 font-semibold">/ {maxDtmScore} ball</span>
          </h1>

          <p className="text-sm text-slate-400 max-w-lg mx-auto mb-6">
            {statusBadge.desc}
          </p>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-xl mx-auto mb-8">
            <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60">
              <span className="text-xs text-slate-400 block mb-0.5">Aniqlik</span>
              <span className="text-xl font-bold text-white">{percentage}%</span>
            </div>
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30">
              <span className="text-xs text-emerald-300 block mb-0.5">To‘g‘ri</span>
              <span className="text-xl font-bold text-emerald-400">{correctCount} ta</span>
            </div>
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30">
              <span className="text-xs text-rose-300 block mb-0.5">Xato</span>
              <span className="text-xl font-bold text-rose-400">{wrongCount} ta</span>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60">
              <span className="text-xs text-slate-400 block mb-0.5">Belgilanmagan</span>
              <span className="text-xl font-bold text-slate-300">{unansweredCount} ta</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              id="result-restart-btn"
              onClick={onRestart}
              className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Qaytadan topshirish</span>
            </button>

            {wrongCount + unansweredCount > 0 && (
              <button
                id="result-mistakes-btn"
                onClick={onStartMistakesPractice}
                className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-semibold text-sm transition-colors"
              >
                <AlertCircle className="w-4 h-4 text-rose-400" />
                <span>Xatolar ustida ishlash ({wrongCount + unansweredCount})</span>
              </button>
            )}

            <button
              id="result-gohome-btn"
              onClick={onGoHome}
              className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Bosh sahifa</span>
            </button>
          </div>
        </div>
      </div>

      {/* Review Section */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Savollarning batafsil tahlili</h2>
            <p className="text-xs text-slate-400">
              Qonun moddalari va to‘g‘ri javoblar izohini o‘rganing
            </p>
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-1.5 bg-slate-900 border border-slate-800 p-1 rounded-xl">
            <button
              id="filter-all-btn"
              onClick={() => setFilterMode('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterMode === 'all'
                  ? 'bg-slate-700 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Barchasi ({total})
            </button>
            <button
              id="filter-wrong-btn"
              onClick={() => setFilterMode('wrong')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterMode === 'wrong'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Xatolar ({wrongCount + unansweredCount})
            </button>
            <button
              id="filter-correct-btn"
              onClick={() => setFilterMode('correct')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterMode === 'correct'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              To‘g‘ri ({correctCount})
            </button>
          </div>
        </div>

        {/* Questions list */}
        <div className="space-y-4">
          {filteredQuestions.map((q, idx) => {
            const userChoice = session.userAnswers[q.id];
            const isCorrect = userChoice === q.correctIndex;
            const isUnanswered = userChoice === undefined;

            return (
              <div
                key={q.id}
                id={`review-item-${q.id}`}
                className={`p-5 rounded-2xl border transition-all ${
                  isCorrect
                    ? 'bg-slate-900/90 border-emerald-500/30'
                    : 'bg-slate-900/90 border-rose-500/30'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between gap-3 mb-3 pb-2 border-b border-slate-800">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`flex items-center space-x-1 text-xs font-bold px-2.5 py-1 rounded-md ${
                        isCorrect
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {isCorrect ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>To‘g‘ri</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3.5 h-3.5" />
                          <span>{isUnanswered ? 'Belgilanmagan' : 'Xato'}</span>
                        </>
                      )}
                    </span>
                    {q.yearOrSource && (
                      <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                        {q.yearOrSource}
                      </span>
                    )}
                  </div>
                  {q.legalBasis && (
                    <span className="text-[11px] font-mono text-emerald-400 bg-slate-950 px-2.5 py-0.5 rounded border border-slate-800">
                      {q.legalBasis}
                    </span>
                  )}
                </div>

                {/* Question text */}
                <p className="text-sm sm:text-base font-semibold text-white mb-4 leading-relaxed">
                  {q.question}
                </p>

                {/* Options Review */}
                <div className="space-y-2 mb-4">
                  {q.options.map((opt, optIdx) => {
                    const isUserPick = userChoice === optIdx;
                    const isTheCorrectOne = q.correctIndex === optIdx;

                    let rowStyle = 'bg-slate-800/40 border-slate-700/50 text-slate-300';
                    let letterStyle = 'bg-slate-700 text-slate-300';

                    if (isTheCorrectOne) {
                      rowStyle =
                        'bg-emerald-950/50 border-emerald-500/60 text-emerald-100 font-medium';
                      letterStyle = 'bg-emerald-500 text-slate-950 font-bold';
                    } else if (isUserPick && !isCorrect) {
                      rowStyle =
                        'bg-rose-950/50 border-rose-500/60 text-rose-100 font-medium';
                      letterStyle = 'bg-rose-500 text-white font-bold';
                    }

                    return (
                      <div
                        key={optIdx}
                        className={`p-3 rounded-xl border text-xs sm:text-sm flex items-start space-x-3 ${rowStyle}`}
                      >
                        <span
                          className={`w-6 h-6 rounded-md flex items-center justify-center text-xs shrink-0 mt-0.5 ${letterStyle}`}
                        >
                          {OPTION_LETTERS[optIdx]}
                        </span>
                        <span className="flex-1">{opt}</span>
                        {isTheCorrectOne && (
                          <span className="text-xs font-semibold text-emerald-400 shrink-0">
                            To‘g‘ri javob
                          </span>
                        )}
                        {isUserPick && !isTheCorrectOne && (
                          <span className="text-xs font-semibold text-rose-400 shrink-0">
                            Sizning javobingiz
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Legal Explanation */}
                <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start space-x-3 text-xs sm:text-sm text-slate-300">
                  <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-300 block mb-0.5">Sharh va huquqiy asos:</strong>
                    <p className="text-slate-300 leading-relaxed">{q.explanation}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
