import React, { useState } from 'react';
import {
  X,
  Settings,
  BookMarked,
  History,
  Search,
  ExternalLink,
  RotateCcw,
  Volume2,
  VolumeX,
  Type,
  Clock,
  Timer,
  ListOrdered,
  Sliders,
  Minus,
  Plus,
  CheckCircle2,
  Shield,
  BookOpen,
  Calendar,
  Sparkles,
  ChevronRight,
  Filter,
  BarChart3
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { AppSettings, ChronologyEvent, LegalSourceItem } from '../types';
import { CHRONOLOGY_EVENTS } from '../data/legalChronology';
import { LEGAL_SOURCES } from '../data/legalSources';

interface ToggleNavMenuProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onClearHistory: () => void;
  onClearMistakes: () => void;
  historyCount: number;
  mistakesCount: number;
  initialTab?: 'sozlamalar' | 'manbalar' | 'xronologiya';
  onOpenStats?: () => void;
}

export const ToggleNavMenu: React.FC<ToggleNavMenuProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onClearHistory,
  onClearMistakes,
  historyCount,
  mistakesCount,
  initialTab = 'sozlamalar',
  onOpenStats
}) => {
  const [activeCatalog, setActiveCatalog] = useState<'sozlamalar' | 'manbalar' | 'xronologiya'>(initialTab);
  const [chronologySearch, setChronologySearch] = useState('');
  const [chronologyFilter, setChronologyFilter] = useState<string>('all');
  const [sourcesFilter, setSourcesFilter] = useState<string>('all');
  const [confirmClearHistory, setConfirmClearHistory] = useState(false);
  const [confirmClearMistakes, setConfirmClearMistakes] = useState(false);

  // Sync initial tab when opening
  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveCatalog(initialTab);
    }
  }, [isOpen, initialTab]);

  // Filter chronology
  const filteredChronology = CHRONOLOGY_EVENTS.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(chronologySearch.toLowerCase()) ||
      item.year.includes(chronologySearch) ||
      item.description.toLowerCase().includes(chronologySearch.toLowerCase()) ||
      (item.dateExact && item.dateExact.toLowerCase().includes(chronologySearch.toLowerCase()));

    const matchesFilter = chronologyFilter === 'all' || item.category === chronologyFilter;

    return matchesSearch && matchesFilter;
  });

  // Filter sources
  const filteredSources = LEGAL_SOURCES.filter((src) => {
    if (sourcesFilter === 'all') return true;
    return src.category === sourcesFilter;
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm cursor-pointer"
          />

          {/* Sliding Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 260 }}
            className="relative w-full max-w-2xl bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col h-full z-10"
          >
            {/* Drawer Header */}
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 backdrop-blur">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white tracking-tight">
                    Navigatsiya Katalogi
                  </h2>
                  <p className="text-xs text-slate-400">
                    Sozlamalar, huquqiy manbalar va yillar xronologiyasi
                  </p>
                </div>
              </div>

              <button
                id="close-toggle-menu-btn"
                onClick={onClose}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                title="Yopish"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Catalog Tabs Selector */}
            <div className="px-6 pt-3 pb-2 border-b border-slate-800 bg-slate-900/50">
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
                <button
                  id="tab-sozlamalar-btn"
                  onClick={() => setActiveCatalog('sozlamalar')}
                  className={`flex items-center justify-center space-x-1.5 py-2.5 px-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                    activeCatalog === 'sozlamalar'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>Sozlamalar</span>
                </button>

                <button
                  id="tab-manbalar-btn"
                  onClick={() => setActiveCatalog('manbalar')}
                  className={`flex items-center justify-center space-x-1.5 py-2.5 px-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                    activeCatalog === 'manbalar'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <BookMarked className="w-4 h-4" />
                  <span>Manbalar</span>
                </button>

                <button
                  id="tab-xronologiya-btn"
                  onClick={() => setActiveCatalog('xronologiya')}
                  className={`flex items-center justify-center space-x-1.5 py-2.5 px-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                    activeCatalog === 'xronologiya'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <History className="w-4 h-4" />
                  <span>Yillar xronologiyasi</span>
                </button>
              </div>
            </div>

            {/* Catalog Body Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* 1. SOZLAMALAR KATALOGI */}
              {activeCatalog === 'sozlamalar' && (
                <div className="space-y-6">
                  {/* Shrift o'lchami */}
                  <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/80 space-y-3">
                    <div className="flex items-center space-x-2 text-white font-semibold text-sm">
                      <Type className="w-4 h-4 text-emerald-400" />
                      <span>Matn shrift o‘lchami</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Savollar va variantlarni o‘qish qulayligi uchun matn hajmini o‘zgartiring:
                    </p>
                    <div className="grid grid-cols-3 gap-2 pt-1">
                      {(['normal', 'large', 'extralarge'] as const).map((size) => (
                        <button
                          key={size}
                          onClick={() => onUpdateSettings({ fontSize: size })}
                          className={`py-2 px-3 rounded-xl border text-xs font-semibold transition-all ${
                            settings.fontSize === size
                              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-600/20'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          {size === 'normal' && 'Standart (16px)'}
                          {size === 'large' && 'Katta (18px)'}
                          {size === 'extralarge' && 'Juda katta (20px)'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 1. Har bir bo'limda savollar soni */}
                  <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/80 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-white font-semibold text-sm">
                        <ListOrdered className="w-4 h-4 text-emerald-400" />
                        <span>Har bir bo‘limda test savollari soni</span>
                      </div>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
                        {settings.questionsPerTopic && settings.questionsPerTopic > 0
                          ? `${settings.questionsPerTopic} ta savol`
                          : 'Barcha savollar'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Mavzuli bo‘limlar testi tanlanganda har bir mavzudan nechtadan savol berilishini belgilang:
                    </p>

                    {/* Tezkor preset tugmalar */}
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                      {[
                        { val: 5, label: '5 ta' },
                        { val: 10, label: '10 ta' },
                        { val: 15, label: '15 ta' },
                        { val: 20, label: '20 ta' },
                        { val: 25, label: '25 ta' },
                        { val: 0, label: 'Barchasi' }
                      ].map((item) => (
                        <button
                          key={item.val}
                          onClick={() => onUpdateSettings({ questionsPerTopic: item.val })}
                          className={`py-2 px-2.5 rounded-xl border text-xs font-semibold transition-all text-center ${
                            settings.questionsPerTopic === item.val
                              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-600/20'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>

                    {/* Ixtiyoriy son kiritish maydoni */}
                    <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-700/50">
                      <span className="text-xs text-slate-300 font-medium">
                        Ixtiyoriy son kiritish:
                      </span>
                      <div className="flex items-center space-x-2">
                        <button
                          type="button"
                          onClick={() => {
                            const current = settings.questionsPerTopic || 10;
                            const next = Math.max(1, current - 1);
                            onUpdateSettings({ questionsPerTopic: next });
                          }}
                          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
                          title="Kamaytirish"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <input
                          type="number"
                          min="1"
                          max="50"
                          value={settings.questionsPerTopic || ''}
                          placeholder="Barchasi"
                          onChange={(e) => {
                            const val = e.target.value === '' ? 0 : parseInt(e.target.value, 10);
                            onUpdateSettings({ questionsPerTopic: isNaN(val) ? 0 : Math.max(0, Math.min(50, val)) });
                          }}
                          className="w-16 text-center py-1 px-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white font-bold focus:outline-none focus:border-emerald-500"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const current = settings.questionsPerTopic || 0;
                            const next = Math.min(50, current + 1);
                            onUpdateSettings({ questionsPerTopic: next });
                          }}
                          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
                          title="Oshirish"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* 2. Asosiy test vaqti taymeri (Erkin o'zgartirish) */}
                  <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/80 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-white font-semibold text-sm">
                        <Clock className="w-4 h-4 text-sky-400" />
                        <span>Asosiy test vaqti taymeri</span>
                      </div>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-300">
                        {settings.defaultTimerMinutes && settings.defaultTimerMinutes > 0
                          ? `${settings.defaultTimerMinutes} daqiqa (${settings.defaultTimerMinutes * 60} soniya)`
                          : 'Cheksiz (Vaqtsiz)'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Asosiy sinov testini bajarish vaqtini o‘zingiz xohlagan daqiqaga erkin o‘zgartiring:
                    </p>

                    {/* Tezkor preset tugmalar */}
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                      {[
                        { val: 0, label: 'Vaqtsiz' },
                        { val: 15, label: '15 daq' },
                        { val: 25, label: '25 daq' },
                        { val: 30, label: '30 daq' },
                        { val: 40, label: '40 daq (DTM)' },
                        { val: 60, label: '60 daq' }
                      ].map((item) => (
                        <button
                          key={item.val}
                          onClick={() => onUpdateSettings({ defaultTimerMinutes: item.val })}
                          className={`py-2 px-2 rounded-xl border text-xs font-semibold transition-all text-center ${
                            settings.defaultTimerMinutes === item.val
                              ? 'bg-sky-600 text-white border-sky-500 shadow-md shadow-sky-600/20'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>

                    {/* Erkin daqiqa sozlagichi (Input + Slider + Tugmalar) */}
                    <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-300 font-medium">
                          Ixtiyoriy daqiqa kiritish:
                        </span>
                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => {
                              const current = settings.defaultTimerMinutes || 0;
                              const next = Math.max(0, current - 5);
                              onUpdateSettings({ defaultTimerMinutes: next });
                            }}
                            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-300 hover:text-white"
                            title="5 daqiqa kamaytirish"
                          >
                            -5 daq
                          </button>
                          <input
                            type="number"
                            min="0"
                            max="180"
                            value={settings.defaultTimerMinutes ?? 40}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10);
                              onUpdateSettings({ defaultTimerMinutes: isNaN(val) ? 0 : Math.max(0, Math.min(180, val)) });
                            }}
                            className="w-16 text-center py-1 px-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white font-bold focus:outline-none focus:border-sky-500"
                          />
                          <span className="text-xs text-slate-400">daq</span>
                          <button
                            type="button"
                            onClick={() => {
                              const current = settings.defaultTimerMinutes || 0;
                              const next = Math.min(180, current + 5);
                              onUpdateSettings({ defaultTimerMinutes: next });
                            }}
                            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-300 hover:text-white"
                            title="5 daqiqa qo‘shish"
                          >
                            +5 daq
                          </button>
                        </div>
                      </div>

                      {/* Slider */}
                      <div className="flex items-center space-x-3 pt-1">
                        <span className="text-[11px] text-slate-500">0 daq</span>
                        <input
                          type="range"
                          min="0"
                          max="120"
                          step="5"
                          value={settings.defaultTimerMinutes ?? 40}
                          onChange={(e) => {
                            onUpdateSettings({ defaultTimerMinutes: parseInt(e.target.value, 10) });
                          }}
                          className="flex-1 accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                        />
                        <span className="text-[11px] text-slate-500">120 daq</span>
                      </div>
                    </div>
                  </div>

                  {/* 3. Mavzuli (bo'lim) testlari taymeri */}
                  <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/80 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-white font-semibold text-sm">
                        <Timer className="w-4 h-4 text-purple-400" />
                        <span>Mavzuli (bo‘lim) testlari taymeri</span>
                      </div>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300">
                        {settings.topicTimerMinutes && settings.topicTimerMinutes > 0
                          ? `${settings.topicTimerMinutes} daqiqa`
                          : 'Cheksiz (Vaqtsiz)'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Har bir huquqiy bo‘lim sinovi uchun taymer vaqtini moslang:
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {[
                        { val: 0, label: 'Vaqtsiz (Erkin)' },
                        { val: 10, label: '10 daqiqa' },
                        { val: 15, label: '15 daqiqa' },
                        { val: 20, label: '20 daqiqa' },
                        { val: 30, label: '30 daqiqa' }
                      ].map((item) => (
                        <button
                          key={item.val}
                          onClick={() => onUpdateSettings({ topicTimerMinutes: item.val })}
                          className={`py-2 px-2 rounded-xl border text-xs font-semibold transition-all text-center ${
                            settings.topicTimerMinutes === item.val
                              ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/20'
                              : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-700/50">
                      <span className="text-xs text-slate-300 font-medium">
                        Ixtiyoriy daqiqa kiritish:
                      </span>
                      <div className="flex items-center space-x-2">
                        <button
                          type="button"
                          onClick={() => {
                            const current = settings.topicTimerMinutes || 0;
                            const next = Math.max(0, current - 1);
                            onUpdateSettings({ topicTimerMinutes: next });
                          }}
                          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
                          title="Kamaytirish"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <input
                          type="number"
                          min="0"
                          max="90"
                          value={settings.topicTimerMinutes ?? 15}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10);
                            onUpdateSettings({ topicTimerMinutes: isNaN(val) ? 0 : Math.max(0, Math.min(90, val)) });
                          }}
                          className="w-16 text-center py-1 px-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white font-bold focus:outline-none focus:border-purple-500"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const current = settings.topicTimerMinutes || 0;
                            const next = Math.min(90, current + 1);
                            onUpdateSettings({ topicTimerMinutes: next });
                          }}
                          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
                          title="Oshirish"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Avtomatik o'tish & Tovush */}
                  <div className="p-5 rounded-2xl bg-slate-800/40 border border-slate-700/80 space-y-4">
                    <h3 className="text-sm font-semibold text-white">
                      Test topshirish jarayoni parametrlari
                    </h3>

                    <div className="flex items-center justify-between py-2 border-b border-slate-700/50">
                      <div>
                        <span className="text-xs sm:text-sm font-medium text-slate-200 block">
                          Javob tanlanganda avtomatik keyingisiga o‘tish
                        </span>
                        <span className="text-[11px] text-slate-400">
                          Variant tanlangach avtomatik keyingi savolga yo‘naltiriladi
                        </span>
                      </div>
                      <button
                        onClick={() => onUpdateSettings({ autoNextOnSelect: !settings.autoNextOnSelect })}
                        className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                          settings.autoNextOnSelect ? 'bg-emerald-600 justify-end' : 'bg-slate-700 justify-start'
                        }`}
                      >
                        <div className="bg-white w-4 h-4 rounded-full shadow-md" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between py-2">
                      <div>
                        <span className="text-xs sm:text-sm font-medium text-slate-200 block">
                          Ovozli effektlar va tebranish
                        </span>
                        <span className="text-[11px] text-slate-400">
                          Test tugashida va tanlovlarda ovozli bildirishnomalar
                        </span>
                      </div>
                      <button
                        onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
                        className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                          settings.soundEnabled ? 'bg-emerald-600 justify-end' : 'bg-slate-700 justify-start'
                        }`}
                      >
                        <div className="bg-white w-4 h-4 rounded-full shadow-md" />
                      </button>
                    </div>
                  </div>

                  {/* Mening Natijalarim & Statistika */}
                  {onOpenStats && (
                    <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-xs sm:text-sm font-semibold text-white block">
                          Mening natijalarim va statistika
                        </span>
                        <span className="text-[11px] text-slate-400">
                          Jami {historyCount} ta test topshirilgan
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          onClose();
                          onOpenStats();
                        }}
                        className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-sm transition-all"
                      >
                        <BarChart3 className="w-3.5 h-3.5" />
                        <span>Natijalarni ko‘rish</span>
                      </button>
                    </div>
                  )}

                  {/* Xotira va natijalar boshqaruvi */}
                  <div className="p-5 rounded-2xl bg-rose-500/5 border border-rose-500/20 space-y-3">
                    <div className="flex items-center space-x-2 text-rose-300 font-semibold text-sm">
                      <RotateCcw className="w-4 h-4 text-rose-400" />
                      <span>Xotirani tozalash</span>
                    </div>
                    <p className="text-xs text-slate-400">
                      Qurilmangizda saqlangan test natijalari yoki xatolar ro‘yxatini tozalash:
                    </p>

                    <div className="flex flex-col sm:flex-row gap-2 pt-2">
                      <button
                        onClick={() => {
                          if (!confirmClearHistory) {
                            setConfirmClearHistory(true);
                          } else {
                            onClearHistory();
                            setConfirmClearHistory(false);
                          }
                        }}
                        className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
                          confirmClearHistory
                            ? 'bg-rose-600 text-white font-bold animate-pulse'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        }`}
                      >
                        {confirmClearHistory ? 'Tasdiqlaysizmi? (Barcha tarix o‘chadi)' : `Natijalar tarixini tozalash (${historyCount})`}
                      </button>

                      <button
                        onClick={() => {
                          if (!confirmClearMistakes) {
                            setConfirmClearMistakes(true);
                          } else {
                            onClearMistakes();
                            setConfirmClearMistakes(false);
                          }
                        }}
                        className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
                          confirmClearMistakes
                            ? 'bg-rose-600 text-white font-bold animate-pulse'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        }`}
                      >
                        {confirmClearMistakes ? 'Tasdiqlaysizmi? (Xatolar o‘chadi)' : `Xatolarni tozalash (${mistakesCount})`}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. MANBALAR KATALOGI */}
              {activeCatalog === 'manbalar' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white">
                        Rasmiy Huquqiy Manbalar va Kodekslar
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Test savollari tuzilgan asosiy qonun hujjatlari va adabiyotlar
                      </p>
                    </div>

                    {/* Filter Pills */}
                    <div className="flex items-center space-x-1.5 overflow-x-auto">
                      {[
                        { id: 'all', label: 'Barchasi' },
                        { id: 'kodeks', label: 'Kodekslar' },
                        { id: 'portal', label: 'Portallar' }
                      ].map((f) => (
                        <button
                          key={f.id}
                          onClick={() => setSourcesFilter(f.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
                            sourcesFilter === f.id
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {filteredSources.map((source) => (
                      <div
                        key={source.id}
                        className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/80 hover:border-emerald-500/40 transition-all space-y-2.5"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              {source.badge}
                            </span>
                            <h4 className="text-sm font-bold text-white mt-1.5">
                              {source.title}
                            </h4>
                          </div>

                          {source.externalUrl && (
                            <a
                              href={source.externalUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 rounded-lg bg-slate-700/60 hover:bg-emerald-600 text-slate-300 hover:text-white transition-colors shrink-0"
                              title="Lex.uz rasmiy matnini ochish"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          )}
                        </div>

                        <p className="text-xs text-slate-300 leading-relaxed">
                          {source.description}
                        </p>

                        <div className="space-y-1 pt-1 border-t border-slate-700/50">
                          {source.details.map((detail, idx) => (
                            <div key={idx} className="flex items-start space-x-2 text-[11px] text-slate-400">
                              <span className="text-emerald-400 font-bold">•</span>
                              <span>{detail}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. YILLAR XRONOLOGIYASI KATALOGI */}
              {activeCatalog === 'xronologiya' && (
                <div className="space-y-4">
                  {/* Search and Category Filters */}
                  <div className="space-y-3">
                    <div className="relative">
                      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        value={chronologySearch}
                        onChange={(e) => setChronologySearch(e.target.value)}
                        placeholder="Yil yoki voqea bo‘yicha qidirish (masalan: 1992, Konstitutsiya, Bayroq)..."
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* Filter Pills */}
                    <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 text-xs">
                      {[
                        { id: 'all', label: `Barchasi (${CHRONOLOGY_EVENTS.length})` },
                        { id: 'qonunlar', label: 'Qonunlar' },
                        { id: 'kodekslar', label: 'Kodekslar' },
                        { id: 'davlat', label: 'Davlat ramzlari va davlatchilik' },
                        { id: 'konstitutsiya', label: 'Konstitutsiya' },
                        { id: 'islohotlar', label: 'Islohotlar' }
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => setChronologyFilter(item.id)}
                          className={`px-3 py-1.5 rounded-lg whitespace-nowrap text-xs font-semibold transition-colors ${
                            chronologyFilter === item.id
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'bg-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Chronology List */}
                  <div className="space-y-3 relative before:absolute before:inset-0 before:left-5 before:w-0.5 before:bg-slate-800">
                    {filteredChronology.length === 0 ? (
                      <div className="text-center py-12 text-slate-400 text-xs">
                        Hech qanday tarixiy sana topilmadi.
                      </div>
                    ) : (
                      filteredChronology.map((event) => (
                        <div
                          key={event.id}
                          className="relative pl-10 group"
                        >
                          {/* Year marker dot */}
                          <div className="absolute left-3.5 top-3 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-slate-900 border-2 border-emerald-500 group-hover:scale-125 transition-transform" />

                          <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/80 hover:border-emerald-500/40 transition-all space-y-2">
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <div className="flex items-center space-x-2">
                                <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-black font-mono border border-emerald-500/30">
                                  {event.year}
                                </span>
                                {event.dateExact && (
                                  <span className="text-[11px] text-slate-400 font-medium flex items-center space-x-1">
                                    <Calendar className="w-3 h-3 text-slate-500" />
                                    <span>{event.dateExact}</span>
                                  </span>
                                )}
                              </div>

                              <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded border ${
                                event.category === 'konstitutsiya'
                                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                                  : event.category === 'kodekslar'
                                  ? 'bg-sky-500/10 text-sky-300 border-sky-500/30'
                                  : event.category === 'qonunlar'
                                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                                  : event.category === 'davlat'
                                  ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
                                  : 'bg-slate-800 text-slate-400 border-slate-700'
                              }`}>
                                {event.category === 'konstitutsiya' && 'Konstitutsiya'}
                                {event.category === 'kodekslar' && 'Kodeks'}
                                {event.category === 'qonunlar' && 'Qonun'}
                                {event.category === 'davlat' && 'Davlat / Ramz'}
                                {event.category === 'islohotlar' && 'Islohot'}
                                {event.category === 'xalqaro' && 'Xalqaro'}
                              </span>
                            </div>

                            <h4 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                              {event.title}
                            </h4>

                            <p className="text-xs text-slate-300 leading-relaxed">
                              {event.description}
                            </p>

                            {event.examTip && (
                              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 flex items-start space-x-2">
                                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                                <div>
                                  <strong className="font-semibold text-amber-200">DTM imtihonida eslab qoling: </strong>
                                  <span>{event.examTip}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Footer info */}
            <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/90 text-center text-xs text-slate-500">
              MODDA • O‘zbekiston qonunchiligi va DTM standarti asosida
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
