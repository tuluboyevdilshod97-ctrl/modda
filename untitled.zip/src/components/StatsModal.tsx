import React from 'react';
import { X, Award, CheckCircle2, XCircle, Clock, Trash2, TrendingUp, Calendar } from 'lucide-react';
import { QuizResultHistory } from '../types';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: QuizResultHistory[];
  onClearHistory: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  isOpen,
  onClose,
  history,
  onClearHistory
}) => {
  if (!isOpen) return null;

  const totalQuizzes = history.length;
  const totalCorrect = history.reduce((acc, h) => acc + h.correctAnswers, 0);
  const totalQuestions = history.reduce((acc, h) => acc + h.totalQuestions, 0);
  const avgPercentage = totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;
  const avgScore = totalQuizzes > 0
    ? (history.reduce((acc, h) => acc + h.scoreBall, 0) / totalQuizzes).toFixed(1)
    : '0.0';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div
        id="stats-modal"
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Mening Natijalarim & Statistika</h2>
              <p className="text-xs text-slate-400">Topshirilgan testlar va o‘zlashtirish ko‘rsatkichlari</p>
            </div>
          </div>
          <button
            id="close-stats-btn"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 text-center">
              <span className="text-xs text-slate-400 block mb-1">Sinovlar soni</span>
              <span className="text-2xl font-black text-white">{totalQuizzes}</span>
              <span className="text-[10px] text-slate-500 block mt-1">marta ishlangan</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 text-center">
              <span className="text-xs text-slate-400 block mb-1">O‘rtacha aniqlik</span>
              <span className={`text-2xl font-black ${avgPercentage >= 70 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {avgPercentage}%
              </span>
              <span className="text-[10px] text-slate-500 block mt-1">to‘g‘ri javoblar</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 text-center">
              <span className="text-xs text-slate-400 block mb-1">O‘rtacha DTM ball</span>
              <span className="text-2xl font-black text-sky-400">{avgScore}</span>
              <span className="text-[10px] text-slate-500 block mt-1">maks. 93.0 ball</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 text-center">
              <span className="text-xs text-slate-400 block mb-1">Jami savollar</span>
              <span className="text-2xl font-black text-white">{totalQuestions}</span>
              <span className="text-[10px] text-emerald-400 block mt-1">{totalCorrect} to‘g‘ri</span>
            </div>
          </div>

          {/* History list */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-200">Oxirgi sinovlar tarixi</h3>
              {history.length > 0 && (
                <button
                  id="clear-stats-btn"
                  onClick={onClearHistory}
                  className="flex items-center space-x-1 text-xs text-rose-400 hover:text-rose-300 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Tarixni tozalash</span>
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="text-center py-10 rounded-xl bg-slate-800/30 border border-dashed border-slate-700 text-slate-400">
                <Award className="w-8 h-8 mx-auto mb-2 text-slate-500" />
                <p className="text-sm">Hali hech qanday test topshirilmagan.</p>
                <p className="text-xs text-slate-500 mt-1">
                  DTM sinovini yoki mavzulashtirilgan mashqlarni boshlang!
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {history.map((h) => {
                  const minutes = Math.floor(h.timeSpentSeconds / 60);
                  const seconds = h.timeSpentSeconds % 60;
                  return (
                    <div
                      key={h.id}
                      className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-4"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center space-x-2 mb-0.5">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              h.mode === 'dtm_exam'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                            }`}
                          >
                            {h.mode === 'dtm_exam' ? 'DTM Imtihon' : 'Mavzuli Mashq'}
                          </span>
                          <span className="text-xs font-semibold text-white truncate">
                            {h.topicTitle}
                          </span>
                        </div>
                        <div className="flex items-center space-x-3 text-[11px] text-slate-400">
                          <span className="flex items-center space-x-1">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            <span>{h.date}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Clock className="w-3 h-3 text-slate-500" />
                            <span>
                              {minutes > 0 ? `${minutes} daq ` : ''}
                              {seconds} son
                            </span>
                          </span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="flex items-center space-x-2 justify-end">
                          <span className="flex items-center space-x-0.5 text-xs text-emerald-400 font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{h.correctAnswers}</span>
                          </span>
                          <span className="flex items-center space-x-0.5 text-xs text-rose-400 font-semibold">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>{h.wrongAnswers}</span>
                          </span>
                        </div>
                        <div className="text-xs font-black text-white mt-0.5">
                          {h.scoreBall > 0 ? `${h.scoreBall} ball` : `${h.scorePercentage}%`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex justify-end">
          <button
            id="stats-close-footer-btn"
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition-colors"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
