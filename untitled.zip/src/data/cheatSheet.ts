import { LegalCheatItem } from '../types';

export const CHEAT_SHEET_ITEMS: LegalCheatItem[] = [
  {
    id: 'yosh-14',
    category: 'yosh',
    title: "14 yosh",
    value: "Qisman muomala layoqati & Og'ir jinoyatlar uchun jazo",
    details: "14 yoshdan 18 yoshgacha bo'lgan voyaga yetmaganlar cheklangan muomala layoqatiga ega. Og'ir va o'ta og'ir jinoyatlar uchun (qasddan odam o'ldirish, talonchilik, bosqinchilik va h.k.) jinoiy javobgarlik 14 yoshdan boshlanadi.",
    article: "FK 27-modda, JK 17-modda"
  },
  {
    id: 'yosh-15',
    category: 'yosh',
    title: "15 yosh",
    value: "Ishga qabul qilish (istisno)",
    details: "Yoshlarni mehnatga tayyorlash uchun umumta'lim maktablari o'quvchilari ota-onalaridan birining yozma roziligi bilan 15 yoshdan yengil ishga qabul qilinishi mumkin.",
    article: "Yangi Mehnat kodeksi, 118-modda"
  },
  {
    id: 'yosh-16',
    category: 'yosh',
    title: "16 yosh",
    value: "Mehnatga qabul qilish & Umumiy jinoiy javobgarlik",
    details: "Ishga qabul qilishga 16 yoshdan yo'l qo'yiladi. Umumiy jinoiy javobgarlik ham qoida tariqasida 16 yoshga to'lgan shaxslarga nisbatan qo'llaniladi.",
    article: "MK 118-modda, JK 17-modda"
  },
  {
    id: 'yosh-18',
    category: 'yosh',
    title: "18 yosh",
    value: "To'liq muomala layoqati, Saylov huquqi, Nikoh yoshi",
    details: "Fuqaro 18 yoshga to'lishi bilan to'liq muomala layoqatiga ega bo'ladi. Faol saylov huquqi (ovoz berish) vujudga keladi. Nikoh yoshi erkaklar va ayollar uchun teng ravishda 18 yosh etib belgilangan.",
    article: "FK 22-modda, Saylov kodeksi 4-modda, OK 15-modda"
  },
  {
    id: 'yosh-21',
    category: 'yosh',
    title: "21 yosh",
    value: "Mahalliy Kengashlar deputatligi",
    details: "Xalq deputatlari viloyat, tuman va shahar Kengashlariga saylanish yoshi 21 yosh etib belgilangan.",
    article: "Saylov kodeksi, 90-modda"
  },
  {
    id: 'yosh-25',
    category: 'yosh',
    title: "25 yosh",
    value: "Qonunchilik palatasi deputatligi & Sudyalik (birinchi marta)",
    details: "Saylov kuni 25 yoshga to'lgan O'zbekiston fuqarosi Qonunchilik palatasi deputati bo'lishi mumkin. Tuman/shahar sudi sudyasi lavozimiga kamida 25 yoshga to'lgan va kamida 5 yillik yuridik stajga ega bo'lgan shaxs tayinlanadi.",
    article: "Konstitutsiya 93-modda, 'Sudlar to'g'risida'gi qonun"
  },
  {
    id: 'yosh-30',
    category: 'yosh',
    title: "30 yosh",
    value: "Viloyat sudi sudyasi",
    details: "Viloyat sudi, Toshkent shahar sudi sudyasi lavozimiga 30 yoshdan kichik bo'lmagan va kamida 7 yillik stajga ega fuqaro saylanishi/tayinlanishi mumkin.",
    article: "'Sudlar to'g'risida'gi qonun"
  },
  {
    id: 'yosh-35',
    category: 'yosh',
    title: "35 yosh",
    value: "Prezidentlik, Oliy sud va Konstitutsiyaviy sud sudyaligi",
    details: "O'zbekiston Respublikasi Prezidenti lavozimiga 35 yoshdan kichik bo'lmagan, davlat tilini yaxshi biladigan, kamida 10 yil O'zbekistonda muqim yashagan fuqaro 7 yil muddatga saylanadi. Oliy sud va Konstitutsiyaviy sud sudyalari ham kamida 35 yoshda bo'lishi shart.",
    article: "Konstitutsiya 106, 131, 132-moddalar"
  },
  {
    id: 'muddat-davo',
    category: 'muddat',
    title: "3 yil",
    value: "Umumiy da'vo muddati",
    details: "Fuqarolik huquqida buzilgan huquqni himoya qilish uchun umumiy da'vo muddati uch yil qilib belgilangan.",
    article: "Fuqarolik kodeksi, 150-modda"
  },
  {
    id: 'muddat-sinov',
    category: 'muddat',
    title: "3 oy (rahbarlar uchun 6 oy)",
    value: "Mehnat shartnomasidagi dastlabki sinov muddati",
    details: "Dastlabki sinov muddati uch oydan, tashkilot rahbarlari va ularning o'rinbosarlari, bosh buxgalterlar uchun esa olti oydan oshmasligi kerak. Homilador ayollar, 3 yoshga to'lmagan bolasi bor ayollar va yangi bitiruvchilarga sinov belgilanmaydi.",
    article: "Yangi Mehnat kodeksi, 130, 131-moddalar"
  },
  {
    id: 'muddat-tatil',
    category: 'muddat',
    title: "21 kalendar kun",
    value: "Yillik asosiy mehnat ta'tili minimumi",
    details: "Yangi Mehnat kodeksiga ko'ra, har yilgi asosiy eng kam mehnat ta'tilining davomiyligi yigirma bir kalendar kundan kam bo'lishi mumkin emas (eski kodeksda 15 ish kuni edi).",
    article: "Yangi Mehnat kodeksi, 217-modda"
  },
  {
    id: 'muddat-mamuriy-qamoq',
    category: 'muddat',
    title: "15 sutka (favqulodda holatda 30 sutka)",
    value: "Ma'muriy qamoq muddati",
    details: "Ma'muriy qamoq o'n besh sutkagacha, favqulodda holat tartibi sharoitida esa o'ttiz sutkagacha bo'lgan muddatga faqat sud tomonidan qo'llaniladi. Homilador ayollar, 12 yoshgacha bolasi bor ayollar, 1-2 guruh nogironlariga nisbatan qo'llanilmaydi.",
    article: "MJtK 29-modda"
  },
  {
    id: 'saylov-muddatlari',
    category: 'saylov',
    title: "7 yil va 5 yil",
    value: "Prezident (7 yil), Parlament va Kengashlar (5 yil)",
    details: "O'zbekiston Respublikasi Prezidentining vakolat muddati yangi Konstitutsiyaga binoan 7 yil. Oliy Majlis Qonunchilik palatasi deputatlari va Senati a'zolarining vakolat muddati esa 5 yil.",
    article: "Konstitutsiya 92, 106-moddalar"
  },
  {
    id: 'parlament-soni',
    category: 'davlat',
    title: "150 deputat & 65 senator",
    value: "Oliy Majlis tarkibi (yangi Konstitutsiya)",
    details: "Qonunchilik palatasi 150 deputatdan iborat. Senat 65 nafar a'zodan (har bir hududdan 4 tadan jami 56 nafar, va Prezident tomonidan tayinlanadigan 9 nafar) iborat bo'ladi.",
    article: "Konstitutsiya 92, 94-moddalar"
  },
  {
    id: 'aliment-miqdori',
    category: 'muddat',
    title: "1/4, 1/3, 1/2 qism",
    value: "Voyaga yetmagan bolalar uchun aliment",
    details: "Ota-onadan aliment sud tartibida har oylik daromaddan: 1 bola uchun — 1/4 qismi, 2 bola uchun — 1/3 qismi, 3 va undan ortiq bola uchun — 1/2 qismi miqdorida undiriladi.",
    article: "Oila kodeksi, 99-modda"
  }
];
