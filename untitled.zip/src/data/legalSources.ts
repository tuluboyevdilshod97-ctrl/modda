import { LegalSourceItem } from '../types';

export const LEGAL_SOURCES: LegalSourceItem[] = [
  {
    id: 'src-konstitutsiya',
    title: 'O‘zbekiston Respublikasi Konstitutsiyasi (Yangi tahrir)',
    category: 'asosiy_qonun',
    badge: '2023-yil 30-aprel referendumi',
    description: 'Mamlakatimizning oliy yuridik kuchga ega Bosh qonuni. Yangi tahrirda inson qadr-qimmati, ijtimoiy davlat tamoyillari va sud hokimiyati mustaqilligi kuchaytirilgan.',
    details: [
      'Tuzilishi: Muqaddima, 6 bo‘lim, 27 bob, 155 modda',
      'Kuchga kirgan sana: 2023-yil 1-may',
      'Asosiy yangiliklar: O‘zbekiston — suveren, demokratik, huquqiy, ijtimoiy va dunyoviy davlat deb e’lon qilindi',
      'Inson huquqlari: «Inson — jamiyat — davlat» ustuvorlik tamoyili'
    ],
    externalUrl: 'https://lex.uz/docs/-6445145'
  },
  {
    id: 'src-mehnat-kodeksi',
    title: 'O‘zbekiston Respublikasining Mehnat kodeksi (Yangi)',
    category: 'kodeks',
    badge: '599 ta modda (2023-yil kuchga kirgan)',
    description: 'Xodimlar va ish beruvchilar o‘rtasidagi yakka tartibdagi hamda jamoaviy mehnat munosabatlarini, mehnatni muhofaza qilish va dam olish huquqlarini tartibga soladi.',
    details: [
      'Qabul qilingan: 2022-yil 28-oktabr, kuchga kirgan: 2023-yil 30-aprel',
      'Xodimning ish vaqti: haftasiga 40 soatdan oshmasligi kerak',
      'Mehnatga qabul qilish: 16 yoshdan (ota-ona roziligi bilan yengil ishga 15 yoshdan)',
      'Sinov muddati: oddiy xodimlar uchun 3 oygacha, rahbar va o‘rinbosarlarga 6 oygacha'
    ],
    externalUrl: 'https://lex.uz/docs/-6257288'
  },
  {
    id: 'src-jinoyat-kodeksi',
    title: 'O‘zbekiston Respublikasining Jinoyat kodeksi',
    category: 'kodeks',
    badge: 'Umumiy va Maxsus qism',
    description: 'Qanday ijtimoiy xavfli qilmishlar jinoyat ekanligini, jazo turlari va ularni tayinlash asoslarini, javobgarlikdan ozod qilish shartlarini belgilaydi.',
    details: [
      'Jinoiy javobgarlik yoshi: umumiy qoida bo‘yicha 16 yosh (og‘ir jinoyatlarda 14 yosh, ayrim moddalarda 13 yoki 18 yosh)',
      'Jazo turlari: Jarima, muayyan huquqdan mahrum qilish, majburiy jamoat ishlari, axloq tuzatish ishlari, ozodlikni cheklash, ozodlikdan mahrum qilish, umrbod ozodlikdan mahrum qilish',
      'O‘lim jazosi O‘zbekistonda butunlay bekor qilingan (2008-yildan)'
    ],
    externalUrl: 'https://lex.uz/docs/-111453'
  },
  {
    id: 'src-fuqarolik-kodeksi',
    title: 'O‘zbekiston Respublikasining Fuqarolik kodeksi',
    category: 'kodeks',
    badge: 'I va II qismlar',
    description: 'Fuqarolar va yuridik shaxslarning mulkiy hamda shaxsiy nomulkiy munosabatlari, bitimlar, shartnomalar, meros huquqi va majburiyatlarni tartibga soladi.',
    details: [
      'To‘la muomala layoqati: 18 yoshga to‘lgach (yoki emansipatsiya orqali 16 yoshdan)',
      'Kichik yoshdagi bolalar (6 yoshdan 14 yoshgacha) — mayda maishiy bitimlarni mustaqil tuza oladilar',
      '14 yoshdan 18 yoshgacha bo‘lganlar — o‘z stipendiyasi, maoshi va intellektual mulki bo‘yicha mustaqil tasarruf huquqiga ega'
    ],
    externalUrl: 'https://lex.uz/docs/-111189'
  },
  {
    id: 'src-oila-kodeksi',
    title: 'O‘zbekiston Respublikasining Oila kodeksi',
    category: 'kodeks',
    badge: '8 bo‘lim, 238 modda',
    description: 'Nikoh tuzish va uni bekor qilish tartibi, er-xotin huquq va majburiyatlari, bolalar ta’minoti (aliment) va vasiylik-homiylik masalalarini qamrab oladi.',
    details: [
      'Nikoh yoshi: erkaklar va ayollar uchun qat’iy 18 yosh',
      'Uzrli sabablar bo‘lganda tuman (shahar) hokimi tomonidan ko‘pi bilan 1 yilga kamaytirilishi mumkin',
      'Aliment miqdori: 1 bola uchun daromadning 1/4 qismi, 2 bola uchun 1/3 qismi, 3 va undan ortiq bola uchun 1/2 qismi'
    ],
    externalUrl: 'https://lex.uz/docs/-104720'
  },
  {
    id: 'src-portal-lexuz',
    title: 'Lex.uz — O‘zbekiston Qonunchilik ma’lumotlari milliy bazasi',
    category: 'portal',
    badge: 'Rasmiy portal',
    description: 'Adliya vazirligi tomonidan yuritiladigan barcha qonunlar, kodekslar, Prezident farmonlari va qarorlarining rasmiy elektron e’lon qilish manbai.',
    details: [
      'Barcha qonun hujjatlarining eng so‘nggi, amaldagi tahrirlari bepul taqdim etiladi',
      'Abituriyentlar yangi o‘zgarishlar va moddalarni tekshirish uchun bevosita foydalanishi tavsiya etiladi'
    ],
    externalUrl: 'https://lex.uz'
  },
  {
    id: 'src-portal-bmba',
    title: 'Bilimni baholash agentligi (DTM) Rasmiy resursi',
    category: 'portal',
    badge: 'Imtihon standarti',
    description: 'Oliy ta’lim muassasalariga kirish test sinovlari dasturlari, huquqshunoslik fani bo‘yicha rasmiy spetsifikatsiyalar va namunaviy topshiriqlar manbai.',
    details: [
      'Huquq fani bo‘yicha tasdiqlangan darsliklar va o‘quv qo‘llanmalar ro‘yxati',
      'Savollar soni: 30 ta asosiy blok (har biri 3.1 ballik qiymatda)'
    ],
    externalUrl: 'https://uzbmb.uz'
  },
  {
    id: 'src-adabiyot-maktab',
    title: 'Davlat va huquq asoslari (8-, 9-, 10-, 11-sinf darsliklari)',
    category: 'adabiyot',
    badge: 'Asosiy o‘quv adabiyotlari',
    description: 'Umumiy o‘rta ta’lim maktablarining Huquq asoslari darsliklari (A.Azizov, O.Karimov, X.Odilqoriyev va b.) DTM imtihon savollarining tayanch manbai hisoblanadi.',
    details: [
      'Davlat va huquq nazariyasi asoslari (Davlat shakllari, funksiyalari, huquqiy normalar)',
      'O‘zbekiston huquq tizimi tarmoqlari',
      'Inson huquqlari umumjahon deklaratsiyasi va xalqaro huquq normalari'
    ]
  }
];
