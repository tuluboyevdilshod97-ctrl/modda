import { Topic } from '../types';

export const TOPICS: Topic[] = [
  {
    id: 'konstitutsiya',
    title: "O'zbekiston Respublikasi Konstitutsiyasi",
    subtitle: "Yangi tahrir (2023-yil 30-aprel referendumi)",
    iconName: 'Scale',
    color: 'emerald',
    badge: 'Eng ko‘p tushadigan',
    description: "Davlat suvereniteti, inson huquq va erkinliklari, Oliy Majlis, Prezidentlik, Sud hokimiyati va mahalliy davlat hokimiyati asoslari."
  },
  {
    id: 'davlat_huquq',
    title: "Davlat va huquq nazariyasi asoslari",
    subtitle: "Davlat belgilari, huquq normalari va manbalari",
    iconName: 'Landmark',
    color: 'blue',
    badge: 'Nazariy poydevor',
    description: "Davlat shakllari (boshqaruv, tuzilish, rejim), huquqiy norma tuzilishi (gipoteza, dispozitsiya, sanksiya), huquqbuzarlik tarkibi."
  },
  {
    id: 'fuqarolik',
    title: "Fuqarolik huquqi",
    subtitle: "Bitimlar, muomala layoqati va mulk huquqi",
    iconName: 'Briefcase',
    color: 'indigo',
    badge: 'Asosiy blok',
    description: "Huquq va muomala layoqati, jismoniy va yuridik shaxslar, mulk shakllari, da'vo muddati va fuqarolik-huquqiy shartnomalar."
  },
  {
    id: 'mehnat',
    title: "Mehnat huquqi",
    subtitle: "Yangi Mehnat Kodeksi qoidalari",
    iconName: 'UserCheck',
    color: 'amber',
    badge: 'Amaliy ahamiyatga ega',
    description: "Mehnat shartnomasi, ishga qabul qilish yoshi, sinov muddati, ish vaqti, ta'tillar (kamida 21 kun) va intizomiy choralar."
  },
  {
    id: 'jinoyat',
    title: "Jinoyat huquqi va javobgarlik",
    subtitle: "Jinoyat tarkibi, jazo turlari va yoshi",
    iconName: 'ShieldAlert',
    color: 'rose',
    badge: 'DTM asosiy bo‘limi',
    description: "Jinoiy javobgarlik yoshi, jinoyat tarkibi elementlari, jazoni yengillashtiruvchi va og'irlashtiruvchi holatlar, zaruriy mudofaa."
  },
  {
    id: 'mamuriy_oila',
    title: "Oila va Ma'muriy huquq",
    subtitle: "Nikoh, aliment, ma'muriy jazo turlari",
    iconName: 'HeartHandshake',
    color: 'purple',
    badge: 'Muhim normalar',
    description: "Nikoh tuzish shartlari va yoshi, aliment undirish miqdorlari, ota-onalik huquqlari, ma'muriy javobgarlik va ma'muriy qamoq."
  }
];
