import { Question } from '../types';
import { USER_QUESTIONS_PART1 } from './userQuestionsPart1';
import { USER_QUESTIONS_PART2 } from './userQuestionsPart2';

// Barcha 131 ta resort qilingan aralash savollar
export const USER_MIXED_QUESTIONS: Question[] = [
  ...USER_QUESTIONS_PART1,
  ...USER_QUESTIONS_PART2
];

// Savollarni tasodifiy (random) aralashtirish funksiyasi
export const shuffleQuestions = (list: Question[]): Question[] => {
  const array = [...list];
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

// Tasodifiy miqdorda aralash savollar olish
export const getRandomUserQuestions = (count: number = 30): Question[] => {
  const shuffled = shuffleQuestions(USER_MIXED_QUESTIONS);
  return shuffled.slice(0, Math.min(count, shuffled.length));
};

// Resort statistikasi (mavzular bo'yicha saralangan holati)
export const USER_QUESTIONS_STATS = {
  total: USER_MIXED_QUESTIONS.length,
  byTopic: {
    konstitutsiya: USER_MIXED_QUESTIONS.filter((q) => q.topicId === 'konstitutsiya').length,
    davlat_huquq: USER_MIXED_QUESTIONS.filter((q) => q.topicId === 'davlat_huquq').length,
    mehnat: USER_MIXED_QUESTIONS.filter((q) => q.topicId === 'mehnat').length,
    jinoyat: USER_MIXED_QUESTIONS.filter((q) => q.topicId === 'jinoyat').length,
    fuqarolik: USER_MIXED_QUESTIONS.filter((q) => q.topicId === 'fuqarolik').length,
    mamuriy_oila: USER_MIXED_QUESTIONS.filter((q) => q.topicId === 'mamuriy_oila').length
  }
};
