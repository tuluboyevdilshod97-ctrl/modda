import React, { useState, useEffect, useRef } from 'react';
import {
  Scale,
  Clock,
  BookOpen,
  Award,
  Sparkles,
  AlertCircle,
  HelpCircle,
  CheckCircle,
  Flame,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  Bookmark,
  History,
  BookMarked,
  Settings,
  Play
} from 'lucide-react';
import { TOPICS } from './data/topics';
import { QUESTIONS } from './data/questions';
import { USER_MIXED_QUESTIONS, shuffleQuestions } from './data/userQuestions';
import { Topic, Question, QuizSession, QuizMode, QuizResultHistory, AppSettings } from './types';
import { Header } from './components/Header';
import { TopicCard } from './components/TopicCard';
import { QuizView } from './components/QuizView';
import { ResultView } from './components/ResultView';
import { StatsModal } from './components/StatsModal';
import { TipsModal } from './components/TipsModal';
import { ToggleNavMenu } from './components/ToggleNavMenu';
import {
  getSavedResults,
  saveResult,
  getSavedMistakes,
  removeMistake,
  clearAllHistory,
  clearMistakesOnly,
  clearResultsOnly
} from './utils/storage';

export default function App() {
  const [activeView, setActiveView] = useState<'home' | 'quiz' | 'result'>('home');
  const [currentSession, setCurrentSession] = useState<QuizSession | null>(null);
  const [history, setHistory] = useState<QuizResultHistory[]>([]);
  const [mistakesIds, setMistakesIds] = useState<string[]>([]);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isTipsOpen, setIsTipsOpen] = useState(false);
  const [isNavMenuOpen, setIsNavMenuOpen] = useState(false);
  const [showNoMistakesNotice, setShowNoMistakesNotice] = useState(false);
  const [navMenuInitialTab, setNavMenuInitialTab] = useState<'sozlamalar' | 'manbalar' | 'xronologiya'>('sozlamalar');
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('huquq_app_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          fontSize: parsed.fontSize || 'normal',
          soundEnabled: parsed.soundEnabled ?? true,
          autoNextOnSelect: parsed.autoNextOnSelect ?? false,
          defaultTimerMinutes: parsed.defaultTimerMinutes !== undefined ? parsed.defaultTimerMinutes : 40,
          questionsPerTopic: parsed.questionsPerTopic !== undefined ? parsed.questionsPerTopic : 10,
          dtmQuestionsCount: parsed.dtmQuestionsCount !== undefined ? parsed.dtmQuestionsCount : 30,
          topicTimerMinutes: parsed.topicTimerMinutes !== undefined ? parsed.topicTimerMinutes : 15
        };
      }
    } catch (e) {
      // ignore
    }
    return {
      fontSize: 'normal',
      soundEnabled: true,
      autoNextOnSelect: false,
      defaultTimerMinutes: 40,
      questionsPerTopic: 10,
      dtmQuestionsCount: 30,
      topicTimerMinutes: 15
    };
  });

  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem('huquq_app_settings', JSON.stringify(updated));
      } catch (e) {
        // ignore
      }
      return updated;
    });
  };

  const handleOpenNavMenu = (tab: 'sozlamalar' | 'manbalar' | 'xronologiya' = 'sozlamalar') => {
    setNavMenuInitialTab(tab);
    setIsNavMenuOpen(true);
  };

  const handleClearHistoryOnly = () => {
    clearResultsOnly();
    setHistory([]);
  };

  const handleClearMistakesOnly = () => {
    clearMistakesOnly();
    setMistakesIds([]);
  };

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Load history and mistakes on mount
  useEffect(() => {
    setHistory(getSavedResults());
    setMistakesIds(getSavedMistakes());
  }, []);

  // Timer effect for quiz
  useEffect(() => {
    if (activeView === 'quiz' && currentSession && !currentSession.isFinished && currentSession.timeLimitSeconds > 0) {
      timerRef.current = setInterval(() => {
        setCurrentSession((prev) => {
          if (!prev) return null;
          if (prev.timeRemainingSeconds <= 1) {
            // Auto finish quiz when time expires
            handleFinishQuiz();
            return { ...prev, timeRemainingSeconds: 0 };
          }
          return {
            ...prev,
            timeRemainingSeconds: prev.timeRemainingSeconds - 1
          };
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [activeView, currentSession?.isFinished, currentSession?.timeLimitSeconds]);

  // Helper to shuffle questions
  const shuffleArray = <T,>(array: T[]): T[] => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  // Start Full DTM Exam
  const handleStartDtmExam = () => {
    // Select questions count based on user settings (default 30)
    const count = settings.dtmQuestionsCount && settings.dtmQuestionsCount > 0
      ? settings.dtmQuestionsCount
      : 30;
    const shuffled = shuffleArray(QUESTIONS);
    const selected = shuffled.slice(0, Math.min(count, QUESTIONS.length));

    // User-configured timer: 0 means unlimited / no timer
    const timerMins = settings.defaultTimerMinutes !== undefined ? settings.defaultTimerMinutes : 40;
    const timerSec = timerMins > 0 ? timerMins * 60 : 0;

    const titleSuffix = timerMins > 0 ? `${timerMins} daqiqa` : 'vaqtsiz rejim';
    const session: QuizSession = {
      mode: 'dtm_exam',
      topicTitle: `DTM Sinovi (${selected.length} ta savol, ${titleSuffix})`,
      questions: selected,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds: timerSec,
      timeRemainingSeconds: timerSec,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Start Custom Mixed Random Quiz (User's special test bank)
  const handleStartMixedQuiz = (questions: Question[], title: string, timeLimitSeconds: number) => {
    const session: QuizSession = {
      mode: 'aralash_test',
      topicTitle: title,
      questions,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds,
      timeRemainingSeconds: timeLimitSeconds,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Handle click on Aralash Test from Header or Hero
  const handleStartAralashDefault = () => {
    const shuffled = shuffleQuestions(USER_MIXED_QUESTIONS);
    handleStartMixedQuiz(
      shuffled.slice(0, 30),
      "Aralash Test: 30 ta Tasodifiy Savol (DTM Standarti)",
      40 * 60
    );
  };

  // Start Topic Quiz or Practice
  const handleSelectTopic = (topic: Topic, mode: 'practice' | 'quiz') => {
    const topicQuestions = QUESTIONS.filter((q) => q.topicId === topic.id);
    let questionsList = mode === 'quiz' ? shuffleArray(topicQuestions) : topicQuestions;

    // Apply questionsPerTopic setting (0 means all available questions in this topic)
    if (settings.questionsPerTopic && settings.questionsPerTopic > 0) {
      questionsList = questionsList.slice(0, settings.questionsPerTopic);
    }

    // Determine timer duration: 0 means unlimited / no timer
    let timeLimit = 0;
    const topicMins = settings.topicTimerMinutes !== undefined ? settings.topicTimerMinutes : 15;
    if (mode === 'quiz') {
      timeLimit = topicMins > 0 ? topicMins * 60 : 0;
    }

    const titleSuffix = mode === 'quiz' && topicMins > 0 ? `, ${topicMins} daqiqa` : '';
    const session: QuizSession = {
      mode: mode === 'practice' ? 'topic_practice' : 'dtm_exam',
      topicId: topic.id,
      topicTitle: `${topic.title} (${questionsList.length} ta savol${titleSuffix})`,
      questions: questionsList,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds: timeLimit,
      timeRemainingSeconds: timeLimit,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Start Mistakes Practice
  const handleStartMistakesPractice = () => {
    const missed = QUESTIONS.filter((q) => mistakesIds.includes(q.id));
    if (missed.length === 0) return;

    const session: QuizSession = {
      mode: 'mistakes_review',
      topicTitle: `Xatolar ustida ishlash (${missed.length} ta savol)`,
      questions: shuffleArray(missed),
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds: 0, // unlimited in practice
      timeRemainingSeconds: 0,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Option selection
  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (!currentSession || currentSession.isFinished) return;

    const updatedAnswers = {
      ...currentSession.userAnswers,
      [questionId]: optionIndex
    };

    // If in mistakes review and answered correctly, remove from mistakes
    const currentQ = currentSession.questions.find((q) => q.id === questionId);
    if (currentSession.mode === 'mistakes_review' && currentQ && currentQ.correctIndex === optionIndex) {
      removeMistake(questionId);
      setMistakesIds(getSavedMistakes());
    }

    setCurrentSession({
      ...currentSession,
      userAnswers: updatedAnswers
    });
  };

  // Toggle mark/flag question
  const handleToggleFlag = (questionId: string) => {
    if (!currentSession) return;
    const isMarked = currentSession.markedQuestions.includes(questionId);
    const updated = isMarked
      ? currentSession.markedQuestions.filter((id) => id !== questionId)
      : [...currentSession.markedQuestions, questionId];

    setCurrentSession({
      ...currentSession,
      markedQuestions: updated
    });
  };

  // Navigation within quiz
  const handleNext = () => {
    if (!currentSession) return;
    if (currentSession.currentIndex < currentSession.questions.length - 1) {
      setCurrentSession({
        ...currentSession,
        currentIndex: currentSession.currentIndex + 1
      });
    }
  };

  const handlePrev = () => {
    if (!currentSession) return;
    if (currentSession.currentIndex > 0) {
      setCurrentSession({
        ...currentSession,
        currentIndex: currentSession.currentIndex - 1
      });
    }
  };

  const handleJumpTo = (index: number) => {
    if (!currentSession) return;
    setCurrentSession({
      ...currentSession,
      currentIndex: index
    });
  };

  // Finish quiz and save result
  const handleFinishQuiz = () => {
    if (!currentSession) return;

    const completedAt = Date.now();
    const timeSpent = Math.max(1, Math.round((completedAt - currentSession.startedAt) / 1000));

    let correctCount = 0;
    let wrongCount = 0;
    let unanswered = 0;
    const incorrectIds: string[] = [];

    currentSession.questions.forEach((q) => {
      const userChoice = currentSession.userAnswers[q.id];
      if (userChoice === undefined) {
        unanswered++;
        incorrectIds.push(q.id);
      } else if (userChoice === q.correctIndex) {
        correctCount++;
      } else {
        wrongCount++;
        incorrectIds.push(q.id);
      }
    });

    const total = currentSession.questions.length;
    const percentage = total > 0 ? Math.round((correctCount / total) * 100) : 0;
    const scoreBall = parseFloat((correctCount * 3.1).toFixed(1));

    const resultRecord: QuizResultHistory = {
      id: 'res_' + Date.now(),
      date: new Date().toLocaleDateString('uz-UZ', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      }),
      mode: currentSession.mode,
      topicTitle: currentSession.topicTitle || 'Huquq testi',
      totalQuestions: total,
      correctAnswers: correctCount,
      wrongAnswers: wrongCount,
      unanswered,
      scorePercentage: percentage,
      scoreBall,
      timeSpentSeconds: timeSpent,
      incorrectQuestionIds: incorrectIds
    };

    saveResult(resultRecord);
    setHistory(getSavedResults());
    setMistakesIds(getSavedMistakes());

    setCurrentSession({
      ...currentSession,
      isFinished: true,
      completedAt
    });

    setActiveView('result');
  };

  const handleRestartQuiz = () => {
    if (!currentSession) return;
    const resetSession: QuizSession = {
      ...currentSession,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeRemainingSeconds: currentSession.timeLimitSeconds,
      isFinished: false,
      startedAt: Date.now()
    };
    setCurrentSession(resetSession);
    setActiveView('quiz');
  };

  const handleGoHome = () => {
    setActiveView('home');
  };

  const handleClearHistory = () => {
    clearAllHistory();
    setHistory([]);
    setMistakesIds([]);
  };

  const fontSizeClass =
    settings.fontSize === 'large'
      ? 'text-[16.5px]'
      : settings.fontSize === 'extralarge'
      ? 'text-[18px]'
      : 'text-[15px]';

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white ${fontSizeClass}`}>
      {/* Global Header */}
      <Header
        onStartDtmExam={handleStartDtmExam}
        onStartAralashTest={handleStartAralashDefault}
        onOpenStats={() => setIsStatsOpen(true)}
        onStartMistakesPractice={handleStartMistakesPractice}
        mistakesCount={mistakesIds.length}
        onGoHome={handleGoHome}
        activeView={activeView}
        onOpenNavMenu={handleOpenNavMenu}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeView === 'home' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
            {/* Hero Section */}
            <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 p-8 sm:p-12 overflow-hidden shadow-2xl">
              {/* Decorative law background element */}
              <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 max-w-3xl space-y-5">
                <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Bilimni baholash agentligi (DTM) standarti asosida</span>
                </div>

                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                  Abituriyentlar uchun <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                    Huquq Fanidan
                  </span>{' '}
                  Tayyorgarlik Testlari
                </h1>

                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  Yangi tahrirdagi Konstitutsiya (2023), yangi Mehnat kodeksi, Fuqarolik, Jinoyat
                  va Oila qonunchiligi bo‘yicha tuzilgan eng so‘nggi test savollari. Har bir savol
                  uchun qonuniy asos (modda) va batafsil izoh mavjud.
                </p>

                {/* Main Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    id="hero-start-dtm-btn"
                    onClick={handleStartDtmExam}
                    className="flex items-center space-x-2 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/30 active:scale-95 transition-all"
                  >
                    <Clock className="w-4 h-4" />
                    <span>Testni boshlaymizmi</span>
                  </button>

                  <button
                    id="hero-mistakes-btn"
                    onClick={handleStartMistakesPractice}
                    className={`flex items-center space-x-2 px-5 py-3.5 rounded-xl font-semibold text-sm transition-colors border ${
                      mistakesIds.length > 0
                        ? 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border-rose-500/30'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border-slate-700'
                    }`}
                    title={
                      mistakesIds.length > 0
                        ? "Xato qilingan savollarni qayta ishlash"
                        : "Hozircha xato qilingan savollar yo‘q"
                    }
                  >
                    <AlertCircle className={`w-4 h-4 ${mistakesIds.length > 0 ? 'text-rose-400' : 'text-slate-400'}`} />
                    <span>Xatolar ustida ishlash ({mistakesIds.length})</span>
                  </button>

                  <button
                    id="hero-sources-btn"
                    onClick={() => handleOpenNavMenu('manbalar')}
                    className="flex items-center space-x-2 px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700 transition-colors"
                  >
                    <BookMarked className="w-4 h-4 text-sky-400" />
                    <span>Manbalar</span>
                  </button>

                  <button
                    id="hero-chronology-btn"
                    onClick={() => handleOpenNavMenu('xronologiya')}
                    className="flex items-center space-x-2 px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700 transition-colors"
                  >
                    <History className="w-4 h-4 text-emerald-400" />
                    <span>Yillar Xronologiyasi</span>
                  </button>
                </div>

                {/* DTM Quick Metrics Banner */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800/80 text-xs">
                  <div>
                    <span className="text-slate-400 block">Jami savollar bazasi:</span>
                    <strong className="text-white text-base">{QUESTIONS.length}+ ta savol</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">DTM formati:</span>
                    <strong className="text-emerald-400 text-base">30 ta / 40 daqiqa</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Ball hisoblash:</span>
                    <strong className="text-sky-400 text-base">Har biri 3.1 ball</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Huquqiy tahrir:</span>
                    <strong className="text-white text-base">2023–2024 yangilangan</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Topics Section */}
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  Mavzulashtirilgan Test Bloklari
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                  Har bir bo‘lim bo‘yicha alohida o‘rganish va sinovdan o‘tish imkoniyati
                </p>
              </div>

              {/* Topics Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {TOPICS.map((topic) => {
                  const qCount = QUESTIONS.filter((q) => q.topicId === topic.id).length;
                  return (
                    <TopicCard
                      key={topic.id}
                      topic={topic}
                      questionCount={qCount}
                      onSelectTopic={handleSelectTopic}
                    />
                  );
                })}
              </div>
            </div>

            {/* DTM Exam Rules, Tips & Shpargalka Box - Mehnat huquqi bo'limi kabi kichik shaklda */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div
                id="dtm-tips-block"
                onClick={() => setIsTipsOpen(true)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setIsTipsOpen(true);
                  }
                }}
                className="group relative bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 rounded-2xl p-6 transition-all duration-200 hover:shadow-xl hover:shadow-amber-950/20 flex flex-col justify-between cursor-pointer"
              >
                <div>
                  {/* Top Badges */}
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 group-hover:bg-amber-500/20 transition-all">
                      <Award className="w-6 h-6" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[11px] font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full">
                        Shpargalka & Tavsiyalar
                      </span>
                      <span className="text-[11px] font-medium text-slate-400 bg-slate-800 px-2 py-1 rounded-full">
                        Muhim mezonlar
                      </span>
                    </div>
                  </div>

                  {/* Title and subtitle */}
                  <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors mb-1">
                    Huquqiy Shpargalka & Tavsiyalar
                  </h3>
                  <p className="text-xs font-medium text-amber-400/90 mb-3">
                    Yoshlar, muddatlar va DTM metodikasi
                  </p>

                  {/* Description */}
                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-3 mb-6">
                    Muhim yosh mezonlari, da'vo va protsessual muddatlar, sud normalari hamda imtihonda 40 daqiqa vaqtni to‘g‘ri boshqarish taktikasi.
                  </p>
                </div>

                {/* Buttons */}
                <div className="pt-4 border-t border-slate-800/80">
                  <button
                    id="btn-quiz-tips"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsTipsOpen(true);
                    }}
                    className="w-full flex items-center justify-center space-x-1.5 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-xs font-semibold text-slate-950 shadow-sm shadow-amber-500/30 transition-all active:scale-95"
                    title="Shpargalka va tavsiyalar blokini ochish"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Tavsiyalar</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quiz View */}
        {activeView === 'quiz' && currentSession && (
          <QuizView
            session={currentSession}
            onSelectOption={handleSelectOption}
            onToggleFlag={handleToggleFlag}
            onNext={handleNext}
            onPrev={handlePrev}
            onJumpTo={handleJumpTo}
            onFinishQuiz={handleFinishQuiz}
            onExitQuiz={handleGoHome}
          />
        )}

        {/* Result View */}
        {activeView === 'result' && currentSession && (
          <ResultView
            session={currentSession}
            onRestart={handleRestartQuiz}
            onGoHome={handleGoHome}
            onStartMistakesPractice={handleStartMistakesPractice}
          />
        )}
      </main>

      {/* Modals */}
      <StatsModal
        isOpen={isStatsOpen}
        onClose={() => setIsStatsOpen(false)}
        history={history}
        onClearHistory={handleClearHistory}
      />

      <TipsModal
        isOpen={isTipsOpen}
        onClose={() => setIsTipsOpen(false)}
        onStartExam={handleStartDtmExam}
      />

      {/* Toggle Navigation Drawer */}
      <ToggleNavMenu
        isOpen={isNavMenuOpen}
        onClose={() => setIsNavMenuOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onClearHistory={handleClearHistoryOnly}
        onClearMistakes={handleClearMistakesOnly}
        historyCount={history.length}
        mistakesCount={mistakesIds.length}
        initialTab={navMenuInitialTab}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded-md bg-[#F59E0B] flex items-center justify-center">
              <span className="font-black text-white text-xs leading-none transform -rotate-12">m</span>
            </div>
            <span className="text-slate-400 font-medium">
              MODDA — Huquq platformasi
            </span>
          </div>
          <span>O‘zbekiston Respublikasi qonunchiligi va DTM standarti asosida</span>
        </div>
      </footer>
    </div>
  );
}
