import React, { useState, useEffect } from 'react';
import {
  Clock,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Flag,
  ArrowLeft,
  Send,
  AlertTriangle,
  Lightbulb
} from 'lucide-react';
import { Question, QuizSession } from '../types';

interface QuizViewProps {
  session: QuizSession;
  onSelectOption: (questionId: string, optionIndex: number) => void;
  onToggleFlag: (questionId: string) => void;
  onNext: () => void;
  onPrev: () => void;
  onJumpTo: (index: number) => void;
  onFinishQuiz: () => void;
  onExitQuiz: () => void;
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'];

export const QuizView: React.FC<QuizViewProps> = ({
  session,
  onSelectOption,
  onToggleFlag,
  onNext,
  onPrev,
  onJumpTo,
  onFinishQuiz,
  onExitQuiz
}) => {
  const [showExplanation, setShowExplanation] = useState(false);
  const [showConfirmFinish, setShowConfirmFinish] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  const currentQ: Question | undefined = session.questions[session.currentIndex];
  const selectedOption = currentQ ? session.userAnswers[currentQ.id] : undefined;
  const isFlagged = currentQ ? session.markedQuestions.includes(currentQ.id) : false;

  // Reset showExplanation when changing questions in practice mode
  useEffect(() => {
    setShowExplanation(false);
  }, [session.currentIndex]);

  if (!currentQ) {
    return (
      <div className="text-center py-20 text-white">
        <p>Savollar topilmadi.</p>
        <button
          onClick={onExitQuiz}
          className="mt-4 px-4 py-2 bg-emerald-600 rounded-lg text-sm"
        >
          Ortga qaytish
        </button>
      </div>
    );
  }

  // Format timer
  const minutes = Math.floor(session.timeRemainingSeconds / 60);
  const seconds = session.timeRemainingSeconds % 60;
  const isTimerLow = session.timeLimitSeconds > 0 && session.timeRemainingSeconds <= 300; // < 5 mins

  const totalAnswered = Object.keys(session.userAnswers).length;
  const totalQuestions = session.questions.length;
  const unansweredCount = totalQuestions - totalAnswered;

  const isPracticeMode = session.mode === 'topic_practice' || session.mode === 'mistakes_review';
  const hasAnsweredCurrent = selectedOption !== undefined;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 mb-6 flex flex-wrap items-center justify-between gap-4">
        {/* Left: Back & Title */}
        <div className="flex items-center space-x-3">
          <button
            id="exit-quiz-btn"
            onClick={() => setShowExitConfirm(true)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Chiqish"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                {session.mode === 'dtm_exam'
                  ? 'DTM Standart Imtihoni'
                  : session.mode === 'mistakes_review'
                  ? 'Xatolar ustida ishlash'
                  : 'Mavzuli mashq'}
              </span>
              {session.topicTitle && (
                <span className="text-xs text-slate-400 hidden sm:inline">
                  • {session.topicTitle}
                </span>
              )}
            </div>
            <h2 className="text-sm sm:text-base font-bold text-white">
              Savol {session.currentIndex + 1} / {totalQuestions}
            </h2>
          </div>
        </div>

        {/* Right: Timer & Flag */}
        <div className="flex items-center space-x-3 ml-auto">
          {/* Timer if applicable */}
          {session.timeLimitSeconds > 0 && (
            <div
              id="quiz-timer-badge"
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border text-sm font-mono font-bold transition-all ${
                isTimerLow
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                  : 'bg-slate-800 text-slate-200 border-slate-700'
              }`}
            >
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>
                {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
              </span>
            </div>
          )}

          {/* Flag button */}
          <button
            id="flag-question-btn"
            onClick={() => onToggleFlag(currentQ.id)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium border transition-colors ${
              isFlagged
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200 hover:bg-slate-700'
            }`}
            title="Qayta ko'rib chiqish uchun belgilash"
          >
            <Flag className={`w-4 h-4 ${isFlagged ? 'fill-amber-400 text-amber-400' : ''}`} />
            <span className="hidden sm:inline">
              {isFlagged ? 'Belgilangan' : 'Belgilash'}
            </span>
          </button>

          {/* Finish Button */}
          <button
            id="finish-quiz-top-btn"
            onClick={() => setShowConfirmFinish(true)}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
          >
            <Send className="w-4 h-4" />
            <span>Yakunlash</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Question Box */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
            {/* Question Badges */}
            <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  {currentQ.difficulty.toUpperCase()}
                </span>
                {currentQ.yearOrSource && (
                  <span className="text-xs font-medium px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    {currentQ.yearOrSource}
                  </span>
                )}
              </div>
              <span className="text-xs text-slate-500 font-mono">
                ID: #{currentQ.id}
              </span>
            </div>

            {/* Question text */}
            <h1 className="text-base sm:text-xl font-medium text-white leading-relaxed mb-8">
              {currentQ.question}
            </h1>

            {/* Options List */}
            <div className="space-y-3">
              {currentQ.options.map((optText, index) => {
                const isSelected = selectedOption === index;
                const isCorrect = currentQ.correctIndex === index;

                let btnStyles =
                  'bg-slate-800/80 hover:bg-slate-750 border-slate-700/80 text-slate-200 hover:border-slate-600';
                let letterBadgeStyles =
                  'bg-slate-700 text-slate-300 border-slate-600';

                if (isSelected) {
                  btnStyles =
                    'bg-emerald-950/40 border-emerald-500/80 text-white shadow-md shadow-emerald-950/40';
                  letterBadgeStyles =
                    'bg-emerald-500 text-slate-950 border-emerald-400 font-bold';
                }

                // In practice mode, if student answered and wants to see correctness
                if (isPracticeMode && hasAnsweredCurrent && (showExplanation || isSelected)) {
                  if (isCorrect) {
                    btnStyles =
                      'bg-emerald-950/60 border-emerald-400 text-emerald-100 shadow-md';
                    letterBadgeStyles =
                      'bg-emerald-500 text-white border-emerald-400 font-bold';
                  } else if (isSelected && !isCorrect) {
                    btnStyles =
                      'bg-rose-950/60 border-rose-500 text-rose-100 shadow-md';
                    letterBadgeStyles =
                      'bg-rose-500 text-white border-rose-400 font-bold';
                  }
                }

                return (
                  <button
                    key={index}
                    id={`option-btn-${index}`}
                    onClick={() => onSelectOption(currentQ.id, index)}
                    className={`w-full p-4 sm:p-4.5 rounded-xl border text-left flex items-start space-x-3.5 transition-all duration-150 ${btnStyles}`}
                  >
                    <span
                      className={`w-7 h-7 rounded-lg border flex items-center justify-center text-xs shrink-0 mt-0.5 transition-colors ${letterBadgeStyles}`}
                    >
                      {OPTION_LETTERS[index]}
                    </span>
                    <span className="text-sm sm:text-base leading-relaxed flex-1">
                      {optText}
                    </span>
                    {isPracticeMode && hasAnsweredCurrent && isCorrect && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    )}
                    {isPracticeMode && hasAnsweredCurrent && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Practice Mode: Explanation Box */}
            {isPracticeMode && (
              <div className="mt-6 pt-4 border-t border-slate-800">
                {!showExplanation ? (
                  <button
                    id="show-explanation-btn"
                    onClick={() => setShowExplanation(true)}
                    className="flex items-center space-x-2 text-xs font-semibold text-emerald-400 hover:text-emerald-300 py-1.5 transition-colors"
                  >
                    <Lightbulb className="w-4 h-4" />
                    <span>Huquqiy asos va to‘g‘ri javob izohini ko‘rish</span>
                  </button>
                ) : (
                  <div
                    id="explanation-box"
                    className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-200 animate-fadeIn space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center space-x-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>
                          To‘g‘ri javob: Variant {OPTION_LETTERS[currentQ.correctIndex]}
                        </span>
                      </span>
                      {currentQ.legalBasis && (
                        <span className="text-[11px] font-mono bg-slate-900 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
                          {currentQ.legalBasis}
                        </span>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm leading-relaxed text-slate-200">
                      {currentQ.explanation}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Bottom Nav: Prev / Next */}
          <div className="flex items-center justify-between gap-4">
            <button
              id="prev-question-btn"
              onClick={onPrev}
              disabled={session.currentIndex === 0}
              className={`flex items-center space-x-2 px-5 py-3 rounded-xl border text-sm font-semibold transition-colors ${
                session.currentIndex === 0
                  ? 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                  : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Oldingi</span>
            </button>

            <span className="text-xs text-slate-400 font-medium">
              Javob berildi: {totalAnswered} / {totalQuestions}
            </span>

            {session.currentIndex === totalQuestions - 1 ? (
              <button
                id="finish-quiz-bottom-btn"
                onClick={() => setShowConfirmFinish(true)}
                className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
              >
                <span>Imtihonni yakunlash</span>
                <Send className="w-4 h-4" />
              </button>
            ) : (
              <button
                id="next-question-btn"
                onClick={onNext}
                className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
              >
                <span>Keyingi</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Right: Question Palette Grid */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Savollar jadvali</h3>
              <span className="text-xs text-slate-400">
                {totalAnswered} / {totalQuestions} belgilandi
              </span>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-5 sm:grid-cols-6 lg:grid-cols-5 gap-2 max-h-[380px] overflow-y-auto pr-1">
              {session.questions.map((q, idx) => {
                const isCurrent = session.currentIndex === idx;
                const isAnswered = session.userAnswers[q.id] !== undefined;
                const isMarked = session.markedQuestions.includes(q.id);

                let cellStyles =
                  'bg-slate-800/80 text-slate-400 border-slate-700/70 hover:border-slate-500';

                if (isAnswered) {
                  cellStyles =
                    'bg-emerald-600 text-white font-bold border-emerald-500 shadow-sm';
                }

                if (isMarked) {
                  cellStyles += ' ring-2 ring-amber-400 ring-offset-1 ring-offset-slate-900';
                }

                if (isCurrent) {
                  cellStyles += ' border-2 border-white ring-2 ring-emerald-400';
                }

                return (
                  <button
                    key={q.id}
                    id={`jump-question-btn-${idx + 1}`}
                    onClick={() => onJumpTo(idx)}
                    className={`h-10 rounded-xl border text-xs font-semibold flex items-center justify-center relative transition-all ${cellStyles}`}
                  >
                    <span>{idx + 1}</span>
                    {isMarked && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full border border-slate-900" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Legend */}
            <div className="mt-5 pt-4 border-t border-slate-800 space-y-2 text-xs text-slate-400">
              <div className="flex items-center space-x-2">
                <div className="w-3.5 h-3.5 rounded bg-emerald-600 border border-emerald-500" />
                <span>Javob berilgan</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3.5 h-3.5 rounded bg-slate-800 border border-slate-700" />
                <span>Javob berilmagan</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3.5 h-3.5 rounded bg-slate-800 border border-amber-400 ring-2 ring-amber-400/50" />
                <span>Ko‘rib chiqishga belgilangan</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm Finish Modal */}
      {showConfirmFinish && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">
              Testni yakunlashni tasdiqlaysizmi?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-4">
              Jami savollar: <strong className="text-white">{totalQuestions} ta</strong>
              <br />
              Belgilangan: <strong className="text-emerald-400">{totalAnswered} ta</strong>
              <br />
              Belgilanmagan:{' '}
              <strong className={unansweredCount > 0 ? 'text-rose-400' : 'text-slate-400'}>
                {unansweredCount} ta
              </strong>
            </p>
            {unansweredCount > 0 && (
              <p className="text-xs text-amber-400/90 bg-amber-500/10 border border-amber-500/20 p-2.5 rounded-lg mb-6">
                Eslatma: Belgilanmagan savollar noto‘g‘ri javob deb hisoblanadi.
              </p>
            )}
            <div className="flex items-center justify-end space-x-3">
              <button
                id="cancel-finish-modal-btn"
                onClick={() => setShowConfirmFinish(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-medium text-slate-300"
              >
                Davom etish
              </button>
              <button
                id="confirm-finish-modal-btn"
                onClick={() => {
                  setShowConfirmFinish(false);
                  onFinishQuiz();
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-sm font-bold text-white shadow-md shadow-emerald-600/20"
              >
                Ha, natijani ko‘rish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-2">Testdan chiqish</h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-6">
              Hozir chiqib ketsangiz, joriy javoblaringiz saqlanmasligi mumkin. Haqiqatan ham
              bosh sahifaga qaytmoqchimisiz?
            </p>
            <div className="flex items-center justify-end space-x-3">
              <button
                id="cancel-exit-modal-btn"
                onClick={() => setShowExitConfirm(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-medium text-slate-300"
              >
                Bekor qilish
              </button>
              <button
                id="confirm-exit-modal-btn"
                onClick={() => {
                  setShowExitConfirm(false);
                  onExitQuiz();
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-sm font-bold text-white"
              >
                Ha, chiqish
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
