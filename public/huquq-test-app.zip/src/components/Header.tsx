import React from 'react';
import { Scale, BookOpen, Clock, BarChart3, AlertCircle, Sparkles } from 'lucide-react';

interface HeaderProps {
  onStartDtmExam: () => void;
  onOpenCheatSheet: () => void;
  onOpenStats: () => void;
  onStartMistakesPractice: () => void;
  mistakesCount: number;
  onGoHome: () => void;
  activeView: 'home' | 'quiz' | 'result';
}

export const Header: React.FC<HeaderProps> = ({
  onStartDtmExam,
  onOpenCheatSheet,
  onOpenStats,
  onStartMistakesPractice,
  mistakesCount,
  onGoHome,
  activeView
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand */}
          <button
            onClick={onGoHome}
            id="brand-logo-btn"
            className="flex items-center space-x-3 text-left focus:outline-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                  HuquqTest
                </span>
                <span className="text-[10px] uppercase font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                  DTM 2024–2025
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Abituriyentlar uchun huquq fanidan onlayn test markazi
              </p>
            </div>
          </button>

          {/* Quick Nav Controls */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Shpargalka */}
            <button
              id="header-cheatsheet-btn"
              onClick={onOpenCheatSheet}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/60 transition-colors"
              title="Muhim yoshlar va muddatlar ma'lumotnomasi"
            >
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span className="hidden md:inline">Huquqiy</span>
              <span>Shpargalka</span>
            </button>

            {/* Mistakes Practice */}
            {mistakesCount > 0 && (
              <button
                id="header-mistakes-btn"
                onClick={onStartMistakesPractice}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border border-rose-500/30 transition-colors"
                title="Xato qilingan savollarni qayta ishlash"
              >
                <AlertCircle className="w-4 h-4 text-rose-400" />
                <span className="hidden sm:inline">Xatolar</span>
                <span className="bg-rose-500 text-white text-xs px-1.5 py-0.2 rounded-full font-bold">
                  {mistakesCount}
                </span>
              </button>
            )}

            {/* Stats */}
            <button
              id="header-stats-btn"
              onClick={onOpenStats}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/60 transition-colors"
              title="Mening natijalarim va tahlil"
            >
              <BarChart3 className="w-4 h-4 text-sky-400" />
              <span className="hidden sm:inline">Natijalarim</span>
            </button>

            {/* DTM Exam CTA */}
            {activeView !== 'quiz' && (
              <button
                id="header-dtm-cta-btn"
                onClick={onStartDtmExam}
                className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 active:scale-95 transition-all"
              >
                <Clock className="w-4 h-4" />
                <span>DTM Sinov</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
