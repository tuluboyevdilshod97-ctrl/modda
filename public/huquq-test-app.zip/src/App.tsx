import React, { useState, useEffect, useRef } from 'react';
import {
  Scale,
  Clock,
  BookOpen,
  Award,
  Sparkles,
  AlertCircle,
  HelpCircle,
  Search,
  CheckCircle,
  Flame,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  Bookmark
} from 'lucide-react';
import { TOPICS } from './data/topics';
import { QUESTIONS } from './data/questions';
import { Topic, Question, QuizSession, QuizMode, QuizResultHistory } from './types';
import { Header } from './components/Header';
import { TopicCard } from './components/TopicCard';
import { QuizView } from './components/QuizView';
import { ResultView } from './components/ResultView';
import { CheatSheetModal } from './components/CheatSheetModal';
import { StatsModal } from './components/StatsModal';
import {
  getSavedResults,
  saveResult,
  getSavedMistakes,
  removeMistake,
  clearAllHistory
} from './utils/storage';

export default function App() {
  const [activeView, setActiveView] = useState<'home' | 'quiz' | 'result'>('home');
  const [currentSession, setCurrentSession] = useState<QuizSession | null>(null);
  const [history, setHistory] = useState<QuizResultHistory[]>([]);
  const [mistakesIds, setMistakesIds] = useState<string[]>([]);
  const [isCheatSheetOpen, setIsCheatSheetOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [searchTopicQuery, setSearchTopicQuery] = useState('');

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Load history and mistakes on mount
  useEffect(() => {
    setHistory(getSavedResults());
    setMistakesIds(getSavedMistakes());
  }, []);

  // Timer effect for quiz
  useEffect(() => {
    if (activeView === 'quiz' && currentSession && !currentSession.isFinished && currentSession.timeLimitSeconds > 0) {
      timerRef.current = setInterval(() => {
        setCurrentSession((prev) => {
          if (!prev) return null;
          if (prev.timeRemainingSeconds <= 1) {
            // Auto finish quiz when time expires
            handleFinishQuiz();
            return { ...prev, timeRemainingSeconds: 0 };
          }
          return {
            ...prev,
            timeRemainingSeconds: prev.timeRemainingSeconds - 1
          };
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [activeView, currentSession?.isFinished, currentSession?.timeLimitSeconds]);

  // Helper to shuffle questions
  const shuffleArray = <T,>(array: T[]): T[] => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  // Start Full DTM Exam
  const handleStartDtmExam = () => {
    // Select up to 30 random questions from the entire bank
    const shuffled = shuffleArray(QUESTIONS);
    const selected = shuffled.slice(0, 30);

    const session: QuizSession = {
      mode: 'dtm_exam',
      topicTitle: 'DTM Standart Sinovi (30 ta savol)',
      questions: selected,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds: 40 * 60, // 40 minutes for 30 questions
      timeRemainingSeconds: 40 * 60,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Start Topic Quiz or Practice
  const handleSelectTopic = (topic: Topic, mode: 'practice' | 'quiz') => {
    const topicQuestions = QUESTIONS.filter((q) => q.topicId === topic.id);
    const questionsList = mode === 'quiz' ? shuffleArray(topicQuestions) : topicQuestions;

    const timeLimit = mode === 'quiz' ? topicQuestions.length * 90 : 0; // 90 seconds per question in quiz mode

    const session: QuizSession = {
      mode: mode === 'practice' ? 'topic_practice' : 'dtm_exam',
      topicId: topic.id,
      topicTitle: topic.title,
      questions: questionsList,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds: timeLimit,
      timeRemainingSeconds: timeLimit,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Start Mistakes Practice
  const handleStartMistakesPractice = () => {
    const missed = QUESTIONS.filter((q) => mistakesIds.includes(q.id));
    if (missed.length === 0) return;

    const session: QuizSession = {
      mode: 'mistakes_review',
      topicTitle: `Xatolar ustida ishlash (${missed.length} ta savol)`,
      questions: shuffleArray(missed),
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeLimitSeconds: 0, // unlimited in practice
      timeRemainingSeconds: 0,
      isFinished: false,
      startedAt: Date.now()
    };

    setCurrentSession(session);
    setActiveView('quiz');
  };

  // Option selection
  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (!currentSession || currentSession.isFinished) return;

    const updatedAnswers = {
      ...currentSession.userAnswers,
      [questionId]: optionIndex
    };

    // If in mistakes review and answered correctly, remove from mistakes
    const currentQ = currentSession.questions.find((q) => q.id === questionId);
    if (currentSession.mode === 'mistakes_review' && currentQ && currentQ.correctIndex === optionIndex) {
      removeMistake(questionId);
      setMistakesIds(getSavedMistakes());
    }

    setCurrentSession({
      ...currentSession,
      userAnswers: updatedAnswers
    });
  };

  // Toggle mark/flag question
  const handleToggleFlag = (questionId: string) => {
    if (!currentSession) return;
    const isMarked = currentSession.markedQuestions.includes(questionId);
    const updated = isMarked
      ? currentSession.markedQuestions.filter((id) => id !== questionId)
      : [...currentSession.markedQuestions, questionId];

    setCurrentSession({
      ...currentSession,
      markedQuestions: updated
    });
  };

  // Navigation within quiz
  const handleNext = () => {
    if (!currentSession) return;
    if (currentSession.currentIndex < currentSession.questions.length - 1) {
      setCurrentSession({
        ...currentSession,
        currentIndex: currentSession.currentIndex + 1
      });
    }
  };

  const handlePrev = () => {
    if (!currentSession) return;
    if (currentSession.currentIndex > 0) {
      setCurrentSession({
        ...currentSession,
        currentIndex: currentSession.currentIndex - 1
      });
    }
  };

  const handleJumpTo = (index: number) => {
    if (!currentSession) return;
    setCurrentSession({
      ...currentSession,
      currentIndex: index
    });
  };

  // Finish quiz and save result
  const handleFinishQuiz = () => {
    if (!currentSession) return;

    const completedAt = Date.now();
    const timeSpent = Math.max(1, Math.round((completedAt - currentSession.startedAt) / 1000));

    let correctCount = 0;
    let wrongCount = 0;
    let unanswered = 0;
    const incorrectIds: string[] = [];

    currentSession.questions.forEach((q) => {
      const userChoice = currentSession.userAnswers[q.id];
      if (userChoice === undefined) {
        unanswered++;
        incorrectIds.push(q.id);
      } else if (userChoice === q.correctIndex) {
        correctCount++;
      } else {
        wrongCount++;
        incorrectIds.push(q.id);
      }
    });

    const total = currentSession.questions.length;
    const percentage = total > 0 ? Math.round((correctCount / total) * 100) : 0;
    const scoreBall = parseFloat((correctCount * 3.1).toFixed(1));

    const resultRecord: QuizResultHistory = {
      id: 'res_' + Date.now(),
      date: new Date().toLocaleDateString('uz-UZ', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      }),
      mode: currentSession.mode,
      topicTitle: currentSession.topicTitle || 'Huquq testi',
      totalQuestions: total,
      correctAnswers: correctCount,
      wrongAnswers: wrongCount,
      unanswered,
      scorePercentage: percentage,
      scoreBall,
      timeSpentSeconds: timeSpent,
      incorrectQuestionIds: incorrectIds
    };

    saveResult(resultRecord);
    setHistory(getSavedResults());
    setMistakesIds(getSavedMistakes());

    setCurrentSession({
      ...currentSession,
      isFinished: true,
      completedAt
    });

    setActiveView('result');
  };

  const handleRestartQuiz = () => {
    if (!currentSession) return;
    const resetSession: QuizSession = {
      ...currentSession,
      currentIndex: 0,
      userAnswers: {},
      markedQuestions: [],
      timeRemainingSeconds: currentSession.timeLimitSeconds,
      isFinished: false,
      startedAt: Date.now()
    };
    setCurrentSession(resetSession);
    setActiveView('quiz');
  };

  const handleGoHome = () => {
    setActiveView('home');
  };

  const handleClearHistory = () => {
    clearAllHistory();
    setHistory([]);
    setMistakesIds([]);
  };

  // Filter topics for search
  const filteredTopics = TOPICS.filter((t) =>
    t.title.toLowerCase().includes(searchTopicQuery.toLowerCase()) ||
    t.subtitle.toLowerCase().includes(searchTopicQuery.toLowerCase()) ||
    t.description.toLowerCase().includes(searchTopicQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Global Header */}
      <Header
        onStartDtmExam={handleStartDtmExam}
        onOpenCheatSheet={() => setIsCheatSheetOpen(true)}
        onOpenStats={() => setIsStatsOpen(true)}
        onStartMistakesPractice={handleStartMistakesPractice}
        mistakesCount={mistakesIds.length}
        onGoHome={handleGoHome}
        activeView={activeView}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeView === 'home' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
            {/* Hero Section */}
            <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 p-8 sm:p-12 overflow-hidden shadow-2xl">
              {/* Decorative law background element */}
              <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 max-w-3xl space-y-5">
                <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Bilimni baholash agentligi (DTM) standarti asosida</span>
                </div>

                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                  Abituriyentlar uchun <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                    Huquq Fanidan
                  </span>{' '}
                  Tayyorgarlik Testlari
                </h1>

                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  Yangi tahrirdagi Konstitutsiya (2023), yangi Mehnat kodeksi, Fuqarolik, Jinoyat
                  va Oila qonunchiligi bo‘yicha tuzilgan eng so‘nggi test savollari. Har bir savol
                  uchun qonuniy asos (modda) va batafsil izoh mavjud.
                </p>

                {/* Main Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    id="hero-start-dtm-btn"
                    onClick={handleStartDtmExam}
                    className="flex items-center space-x-2 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-xl shadow-emerald-600/30 active:scale-95 transition-all"
                  >
                    <Clock className="w-4 h-4" />
                    <span>DTM Sinov Testini Boshlash (30 ta savol)</span>
                  </button>

                  <button
                    id="hero-cheatsheet-btn"
                    onClick={() => setIsCheatSheetOpen(true)}
                    className="flex items-center space-x-2 px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700 transition-colors"
                  >
                    <BookOpen className="w-4 h-4 text-emerald-400" />
                    <span>Muhim Yoshlar & Muddatlar</span>
                  </button>

                  {mistakesIds.length > 0 && (
                    <button
                      id="hero-mistakes-btn"
                      onClick={handleStartMistakesPractice}
                      className="flex items-center space-x-2 px-5 py-3.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-semibold text-sm transition-colors"
                    >
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                      <span>Xatolar ustida ishlash ({mistakesIds.length})</span>
                    </button>
                  )}
                </div>

                {/* DTM Quick Metrics Banner */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800/80 text-xs">
                  <div>
                    <span className="text-slate-400 block">Jami savollar bazasi:</span>
                    <strong className="text-white text-base">{QUESTIONS.length}+ ta savol</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">DTM formati:</span>
                    <strong className="text-emerald-400 text-base">30 ta / 40 daqiqa</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Ball hisoblash:</span>
                    <strong className="text-sky-400 text-base">Har biri 3.1 ball</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Huquqiy tahrir:</span>
                    <strong className="text-white text-base">2023–2024 yangilangan</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Topics Section */}
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-white tracking-tight">
                    Mavzulashtirilgan Test Bloklari
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                    Har bir bo‘lim bo‘yicha alohida o‘rganish va sinovdan o‘tish imkoniyati
                  </p>
                </div>

                {/* Search */}
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    id="search-topics-input"
                    value={searchTopicQuery}
                    onChange={(e) => setSearchTopicQuery(e.target.value)}
                    placeholder="Mavzulardan qidirish..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>
              </div>

              {/* Topics Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTopics.map((topic) => {
                  const qCount = QUESTIONS.filter((q) => q.topicId === topic.id).length;
                  return (
                    <TopicCard
                      key={topic.id}
                      topic={topic}
                      questionCount={qCount}
                      onSelectTopic={handleSelectTopic}
                    />
                  );
                })}
              </div>
            </div>

            {/* DTM Exam Rules & Tips Box */}
            <div className="bg-slate-900/70 border border-slate-800 rounded-3xl p-6 sm:p-8">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    Huquq fanidan DTM testlariga tayyorgarlik bo‘yicha tavsiyalar
                  </h3>
                  <p className="text-xs text-slate-400">Yuridik oliygohlarga kiruvchilar uchun foydali eslatmalar</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs sm:text-sm text-slate-300 mt-4">
                <div className="p-4 rounded-xl bg-slate-850 border border-slate-800 space-y-1.5">
                  <strong className="text-white block font-semibold text-emerald-400">
                    1. Konstitutsiyaning yangi moddalari
                  </strong>
                  <p className="text-slate-400 leading-relaxed">
                    2023-yilgi tahrirda inson huquqlari (Miranda qoidasi, Habeas Corpus), Senat a'zolari soni (65 nafar), Prezidentlik muddati (7 yil) kabi normalar eng ko‘p tushadi.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-850 border border-slate-800 space-y-1.5">
                  <strong className="text-white block font-semibold text-sky-400">
                    2. Yoshlar va Muddatlar shpargalkasi
                  </strong>
                  <p className="text-slate-400 leading-relaxed">
                    14, 16, 18, 21, 25, 30, 35 yoshlar bilan bog‘liq lavozimlar hamda umumiy da’vo muddati (3 yil), yangi mehnat ta’tili (kamida 21 kun) mezonlarini doimo esda tuting.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-850 border border-slate-800 space-y-1.5">
                  <strong className="text-white block font-semibold text-amber-400">
                    3. Xatolar ustida ishlash
                  </strong>
                  <p className="text-slate-400 leading-relaxed">
                    Test davomida noaniq bo‘lgan savollarni belgilab qo‘ying. Test yakunlanganidan so‘ng keltirilgan huquqiy sharh va moddani albatta o‘qib chiqing.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quiz View */}
        {activeView === 'quiz' && currentSession && (
          <QuizView
            session={currentSession}
            onSelectOption={handleSelectOption}
            onToggleFlag={handleToggleFlag}
            onNext={handleNext}
            onPrev={handlePrev}
            onJumpTo={handleJumpTo}
            onFinishQuiz={handleFinishQuiz}
            onExitQuiz={handleGoHome}
          />
        )}

        {/* Result View */}
        {activeView === 'result' && currentSession && (
          <ResultView
            session={currentSession}
            onRestart={handleRestartQuiz}
            onGoHome={handleGoHome}
            onStartMistakesPractice={handleStartMistakesPractice}
          />
        )}
      </main>

      {/* Modals */}
      <CheatSheetModal
        isOpen={isCheatSheetOpen}
        onClose={() => setIsCheatSheetOpen(false)}
      />

      <StatsModal
        isOpen={isStatsOpen}
        onClose={() => setIsStatsOpen(false)}
        history={history}
        onClearHistory={handleClearHistory}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <Scale className="w-4 h-4 text-emerald-500" />
            <span className="text-slate-400 font-medium">
              HuquqTest — Abituriyentlar uchun maxsus huquqiy test platformasi
            </span>
          </div>
          <span>O‘zbekiston Respublikasi qonunchiligi asosida tuzilgan</span>
        </div>
      </footer>
    </div>
  );
}
